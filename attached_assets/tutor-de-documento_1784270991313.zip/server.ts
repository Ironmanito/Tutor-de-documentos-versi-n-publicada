import express from "express";
import http from "http";
import path from "path";
import { createServer as createViteServer } from "vite";
import { WebSocketServer, WebSocket } from "ws";
import { GoogleGenAI, LiveServerMessage, Modality, Type } from "@google/genai";
import dotenv from "dotenv";
import { PDFParse } from "pdf-parse";
import * as mammothModule from "mammoth";
import fs from "fs";

// ES Module compatibility for third-party CommonJS packages
const mammoth = ((mammothModule as any).default || mammothModule) as any;

dotenv.config();

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

const PORT = 3000;

const USER_DB_PATH = path.join(process.cwd(), "user_studies_db.json");

interface SavedStudy {
  id: string;
  title: string;
  files: { name: string; size: number; type?: string }[];
  studyText: string;
  topics: any[];
  unlockedTopics: string[];
  viewMode: string;
  createdAt: string;
}

function readUserDb(): Record<string, SavedStudy[]> {
  try {
    if (!fs.existsSync(USER_DB_PATH)) {
      return {};
    }
    const data = fs.readFileSync(USER_DB_PATH, "utf8");
    return JSON.parse(data) || {};
  } catch (err) {
    console.error("Error reading user studies DB, returning empty:", err);
    return {};
  }
}

function writeUserDb(db: Record<string, SavedStudy[]>) {
  try {
    fs.writeFileSync(USER_DB_PATH, JSON.stringify(db, null, 2), "utf8");
  } catch (err) {
    console.error("Error writing user studies DB:", err);
  }
}

let aiClient: GoogleGenAI | null = null;

function getApiKey(): string | undefined {
  if (process.env.GEMINI_API_KEY) {
    return process.env.GEMINI_API_KEY;
  }
  // Try to find any key in the environment starting with "AIza" or "AIzaSy"
  const keys = Object.keys(process.env);
  for (const k of keys) {
    const val = process.env[k];
    if (val && (val.startsWith("AIzaSy") || val.startsWith("AIza"))) {
      console.log(`Auto-detected Gemini API key in environment variable: ${k}`);
      return val;
    }
  }
  return undefined;
}

function getAiClient(customKey?: string): GoogleGenAI {
  const key = customKey || getApiKey();
  if (!key) {
    throw new Error(
      "La clave API de Gemini (GEMINI_API_KEY) no está configurada. " +
      "Por favor, agrégala en el panel de 'Settings > Secrets' (Configuración > Secretos) en la barra superior o en el panel lateral de AI Studio para activar las funciones de estudio con Inteligencia Artificial."
    );
  }
  if (customKey) {
    return new GoogleGenAI({
      apiKey: customKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

console.log("Lazy initialization helper for Gemini API defined. Initial key present in process.env:", !!process.env.GEMINI_API_KEY);

// HTTP routes
app.get("/api/check-env", (req, res) => {
  const key = getApiKey();
  res.json({
    gemini_key_present: !!key,
    gemini_key_length: key ? key.length : 0,
    node_env: process.env.NODE_ENV
  });
});

app.post("/api/extract-pdf", async (req, res) => {
  try {
    const { fileData, fileName } = req.body;
    if (!fileData) {
      return res.status(400).json({ error: "Falta el contenido del archivo (fileData)" });
    }

    console.log(`[Server File Extraction] Recibida solicitud para extraer texto de: ${fileName || 'documento'}`);
    const buffer = Buffer.from(fileData, 'base64');
    let text = '';

    const isWord = fileName && (fileName.toLowerCase().endsWith('.docx') || fileName.toLowerCase().endsWith('.doc'));

    if (isWord) {
      if (fileName.toLowerCase().endsWith('.doc')) {
        return res.status(400).json({ 
          error: "El formato de Word antiguo (.doc) no está soportado directamente. Por favor, vuelve a guardar tu archivo en Word como formato moderno (.docx) o expórtalo a PDF para poder subirlo." 
        });
      }
      console.log(`[Server Word Extraction] Procesando archivo .docx con Mammoth para: ${fileName}`);
      const result = await mammoth.extractRawText({ buffer: buffer });
      text = result.value || '';
    } else {
      console.log(`[Server PDF Extraction] Procesando archivo PDF para: ${fileName}`);
      const parser = new PDFParse({ data: new Uint8Array(buffer) });
      try {
        const parsedData = await parser.getText();
        text = parsedData.text || '';
      } finally {
        await parser.destroy();
      }
    }
    
    console.log(`[Server Extraction] Extracción exitosa de: ${fileName || 'documento'}. Caracteres extraídos: ${text.length}`);
    res.json({ text });
  } catch (error: any) {
    console.error("[Server Extraction] Error parsing file on server:", error);
    res.status(500).json({ error: `No se pudo extraer el texto del archivo en el servidor: ${error.message || error}` });
  }
});

// API endpoints for user studies history
app.get("/api/history", (req, res) => {
  const { email } = req.query;
  if (!email || typeof email !== "string") {
    return res.status(400).json({ error: "Falta el parámetro email" });
  }
  const cleanEmail = email.trim().toLowerCase();
  const db = readUserDb();
  const studies = db[cleanEmail] || [];
  res.json({ studies });
});

app.post("/api/history", (req, res) => {
  const { email, study } = req.body;
  if (!email || !study) {
    return res.status(400).json({ error: "Faltan email o study en la solicitud" });
  }
  const cleanEmail = email.trim().toLowerCase();
  const db = readUserDb();
  
  if (!db[cleanEmail]) {
    db[cleanEmail] = [];
  }
  
  const index = db[cleanEmail].findIndex((s) => s.id === study.id);
  if (index !== -1) {
    db[cleanEmail][index] = study;
  } else {
    db[cleanEmail].unshift(study);
  }
  
  writeUserDb(db);
  res.json({ success: true, study });
});

app.delete("/api/history", (req, res) => {
  const { email, studyId } = req.body;
  if (!email || !studyId) {
    return res.status(400).json({ error: "Faltan email o studyId en la solicitud" });
  }
  const cleanEmail = email.trim().toLowerCase();
  const db = readUserDb();
  
  if (db[cleanEmail]) {
    db[cleanEmail] = db[cleanEmail].filter((s) => s.id !== studyId);
    writeUserDb(db);
  }
  
  res.json({ success: true });
});

app.post("/api/generate-topics", async (req, res) => {
  try {
    const { studyText } = req.body;
    if (!studyText) {
      return res.status(400).json({ error: "Missing studyText" });
    }
    const customKey = req.headers['x-gemini-api-key'] as string | undefined;
    const ai = getAiClient(customKey);
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `Extrae los temas principales del siguiente texto para crear un plan de estudio. Devuelve una lista de 3 a 5 temas.
Texto:
${studyText.substring(0, 50000)}`,
      config: {
        systemInstruction: "Eres un analista de contenido educativo. Extrae temas clave y genera descripciones visuales.",
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING, description: 'Un ID corto y único (ej. tema_1)' },
              title: { type: Type.STRING, description: 'El título del tema' },
              description: { type: Type.STRING, description: 'Una breve descripción del tema' },
              imagePrompt: { type: Type.STRING, description: 'Un prompt en inglés para generar una imagen ilustrativa del tema (ej. "physics gravity apple illustration minimalist")' }
            },
            required: ['id', 'title', 'description', 'imagePrompt']
          }
        }
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Error generating topics:", error);
    res.status(500).json({ error: error.message || "Failed to generate topics" });
  }
});

app.post("/api/generate-quiz", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Missing text" });
    }
    const customKey = req.headers['x-gemini-api-key'] as string | undefined;
    const ai = getAiClient(customKey);
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `Actúa como un profesor experto. Genera un cuestionario de opción múltiple exhaustivo basado en el texto proporcionado. 
El cuestionario debe cubrir todas las ideas principales y secundarias para asegurar una comprensión total del material.
Crea un conjunto completo de preguntas (mínimo 10-15 si el contenido lo permite) para evaluar todo el material.

Texto:
${text.substring(0, 50000)}`,
      config: {
        systemInstruction: "Eres un profesor universitario diseñando un examen final exhaustivo.",
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING }, 
                description: "Exactamente 4 opciones de respuesta" 
              },
              correctIndex: { type: Type.INTEGER, description: "Índice de la respuesta correcta (0 a 3)" },
              explanation: { type: Type.STRING, description: "Breve explicación de por qué es la respuesta correcta" }
            },
            required: ["question", "options", "correctIndex", "explanation"]
          }
        }
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Error generating quiz:", error);
    res.status(500).json({ error: error.message || "Failed to generate quiz" });
  }
});

const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const pathname = request.url ? new URL(request.url, `http://${request.headers.host}`).pathname : '';
  if (pathname === '/api/live') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  } else {
    socket.destroy();
  }
});

wss.on('connection', (clientWs: WebSocket, request: any) => {
  console.log("Client connected to WebSocket proxy");
  let liveSession: any = null;

  // Extract apiKey from query string if available
  let customKey: string | undefined;
  try {
    if (request && request.url) {
      const urlObj = new URL(request.url, `http://${request.headers?.host || 'localhost'}`);
      const keyParam = urlObj.searchParams.get('apiKey');
      if (keyParam) {
        customKey = keyParam;
      }
    }
  } catch (err) {
    console.error("Error parsing WebSocket connection URL for apiKey:", err);
  }

  clientWs.on('message', async (message: string) => {
    try {
      const parsed = JSON.parse(message);
      
      if (parsed.type === 'setup') {
        const { mode, text, topics } = parsed.params;
        
        // Define live config based on the modes
        let systemInstruction = "";
        let tools: any[] = [];
        
        if (mode === 'topics') {
          tools = [{
            functionDeclarations: [{
              name: "unlockTopic",
              description: "Desbloquea la imagen de un tema en la interfaz visual cuando el usuario responde correctamente a una pregunta sobre ese tema.",
              parameters: {
                type: Type.OBJECT,
                properties: {
                  topicId: {
                    type: Type.STRING,
                    description: "El ID del tema a desbloquear."
                  }
                },
                required: ["topicId"]
              }
            }]
          }];
          
          systemInstruction = `Eres un tutor de estudio experto y amigable. El usuario está estudiando un cuaderno con múltiples documentos.
Los temas principales a evaluar son:
${topics ? topics.map((t: any) => `- ID: ${t.id}, Título: ${t.title}, Descripción: ${t.description}`).join('\n') : ''}

Tu objetivo es hacerle un cuestionario al usuario, tema por tema.
Hazle una pregunta sobre el primer tema. Si responde incorrectamente, dale pistas y consejos para ayudarlo a llegar a la respuesta correcta. NO le des la respuesta directamente.
Cuando el usuario responda correctamente a una pregunta sobre un tema, DEBES llamar a la función 'unlockTopic' con el ID de ese tema para desbloquear su imagen en la pantalla. Luego, felicítalo y pasa a hacerle una pregunta sobre el siguiente tema.

IMPORTANTE SOBRE EL TIEMPO DE RESPUESTA: Los humanos a veces hacen pausas largas para pensar. Si el usuario se queda callado a mitad de una oración o la idea parece incompleta, NO lo interrumpas ni evalúes su respuesta todavía. Dile algo como "Tómate tu tiempo..." o "¿Quieres añadir algo más?" y espera a que termine de formular su idea.

Mantén tus respuestas concisas y adecuadas para una conversación hablada en español. Sé proactivo haciendo preguntas si el usuario se queda callado por mucho tiempo sin haber empezado a hablar.

CUADERNO DE ESTUDIO:
${text ? text.substring(0, 50000) : ''}
`;
        } else {
          // Free voice study buddy mode
          systemInstruction = `Eres un tutor de estudio experto y amigable. El usuario ha subido un documento y quiere estudiar dialogando contigo.
Explícale los conceptos, responde sus dudas y hazle preguntas para comprobar su comprensión si lo ves oportuno.

IMPORTANTE SOBRE EL TIEMPO DE RESPUESTA: Los humanos a veces hacen pausas largas para pensar. Si el usuario se queda callado a mitad de una oración o la idea parece incompleta, NO lo interrumpas ni asumas que ha terminado. Dile algo como "Tómate tu tiempo..." o "¿Quieres añadir algo más?" y espera a que termine de formular su idea.

Mantén tus respuestas concisas y adecuadas para una conversación hablada en español. Sé proactivo haciendo preguntas si el usuario se queda callado por mucho tiempo sin haber empezado a hablar.

CUADERNO DE ESTUDIO:
${text ? text.substring(0, 50000) : ''}
`;
        }

        try {
          const ai = getAiClient(customKey);
          liveSession = await ai.live.connect({
            model: "gemini-3.1-flash-live-preview",
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
              },
              tools: tools.length > 0 ? tools : undefined,
              systemInstruction,
            },
            callbacks: {
              onopen: () => {
                clientWs.send(JSON.stringify({ type: 'open' }));
              },
              onmessage: (serverMessage: LiveServerMessage) => {
                clientWs.send(JSON.stringify({ type: 'message', data: serverMessage }));
              },
              onclose: () => {
                clientWs.send(JSON.stringify({ type: 'close' }));
              },
              onerror: (err) => {
                clientWs.send(JSON.stringify({ type: 'error', data: err?.message || String(err) }));
              }
            }
          });
        } catch (connErr: any) {
          console.error("Gemini Live connection failed:", connErr);
          clientWs.send(JSON.stringify({ type: 'error', data: `Error al conectar con la API de Gemini Live: ${connErr.message || connErr}` }));
        }
      } else if (parsed.type === 'realtimeInput') {
        if (liveSession) {
          liveSession.sendRealtimeInput(parsed.data);
        }
      } else if (parsed.type === 'toolResponse') {
        if (liveSession) {
          liveSession.sendToolResponse(parsed.data);
        }
      }
    } catch (err: any) {
      console.error("WebSocket proxy error processing client message:", err);
    }
  });

  clientWs.on('close', () => {
    console.log("Client disconnected from WebSocket proxy");
    if (liveSession) {
      liveSession.close();
      liveSession = null;
    }
  });
});

async function startViteDevServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startViteDevServer();
