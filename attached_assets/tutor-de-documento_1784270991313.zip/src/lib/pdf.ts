export async function extractTextFromPDF(file: File): Promise<string> {
  // Convert File to Base64 in a non-blocking, safe way compatible with all browsers
  const base64 = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      if (!result) {
        reject(new Error("No se pudo leer el archivo."));
        return;
      }
      const base64Data = result.split(',')[1];
      resolve(base64Data);
    };
    reader.onerror = () => reject(new Error("Error al leer el archivo desde el navegador."));
    reader.readAsDataURL(file);
  });

  // Call the server-side extraction endpoint which supports PDF and Word (.docx)
  const res = await fetch("/api/extract-pdf", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fileName: file.name, fileData: base64 })
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || `Error del servidor al extraer el archivo (${res.status})`);
  }

  const data = await res.json();
  return data.text || '';
}

export async function extractTextFromFile(file: File): Promise<string> {
  const isPDF = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
  const isWord = file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
                  file.type === 'application/msword' ||
                  file.name.toLowerCase().endsWith('.docx') ||
                  file.name.toLowerCase().endsWith('.doc');

  if (isPDF || isWord) {
    return await extractTextFromPDF(file);
  } else if (file.type.startsWith('text/') || file.name.endsWith('.md') || file.name.endsWith('.txt') || file.name.endsWith('.csv')) {
    return await file.text();
  } else {
    throw new Error(`Tipo de archivo no soportado: ${file.name}`);
  }
}
