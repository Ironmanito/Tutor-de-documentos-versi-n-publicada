import React, { useState, useRef, useEffect } from 'react';
import { UploadCloud, FileText, Mic, Square, Loader2, BookOpen, Volume2, Plus, Trash2, Lock, Unlock, Image as ImageIcon, Sparkles, ListChecks, CheckCircle2, XCircle, ArrowRight, AlertTriangle, Key, Check, ExternalLink, HelpCircle, CreditCard, Coins, DollarSign } from 'lucide-react';
import { extractTextFromFile } from './lib/pdf';
import { AudioStreamPlayer, AudioRecorder } from './lib/audio';
import { cn } from './lib/utils';
import { motion, AnimatePresence } from 'motion/react';

class WebSocketSession {
  private ws: WebSocket;
  private onOpenCallback?: () => void;
  private onMessageCallback?: (message: any) => void;
  private onCloseCallback?: () => void;
  private onErrorCallback?: (err: any) => void;

  constructor(params: { mode: string; text: string; topics?: any }) {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const host = window.location.host;
    const savedKey = localStorage.getItem('user_gemini_api_key');
    const queryParam = savedKey ? `?apiKey=${encodeURIComponent(savedKey)}` : '';
    this.ws = new WebSocket(`${protocol}//${host}/api/live${queryParam}`);

    this.ws.onopen = () => {
      console.log("WebSocket connection opened, sending setup message...");
      this.ws.send(JSON.stringify({ type: 'setup', params }));
    };

    this.ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'open') {
          console.log("Gemini Live session successfully initialized on server.");
          if (this.onOpenCallback) {
            this.onOpenCallback();
          }
        } else if (msg.type === 'message') {
          if (this.onMessageCallback) {
            this.onMessageCallback(msg.data);
          }
        } else if (msg.type === 'close') {
          if (this.onCloseCallback) {
            this.onCloseCallback();
          }
        } else if (msg.type === 'error') {
          if (this.onErrorCallback) {
            this.onErrorCallback(new Error(msg.data));
          }
        }
      } catch (err) {
        console.error("Error parsing WebSocket message from proxy:", err);
      }
    };

    this.ws.onclose = () => {
      console.log("WebSocket connection closed.");
      if (this.onCloseCallback) {
        this.onCloseCallback();
      }
    };

    this.ws.onerror = (err) => {
      console.error("WebSocket connection error:", err);
      if (this.onErrorCallback) {
        this.onErrorCallback(err);
      }
    };
  }

  setCallbacks(callbacks: {
    onopen?: () => void;
    onmessage?: (msg: any) => void;
    onclose?: () => void;
    onerror?: (err: any) => void;
  }) {
    this.onOpenCallback = callbacks.onopen;
    this.onMessageCallback = callbacks.onmessage;
    this.onCloseCallback = callbacks.onclose;
    this.onErrorCallback = callbacks.onerror;
  }

  sendRealtimeInput(data: any) {
    if (this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'realtimeInput', data }));
    }
  }

  sendToolResponse(data: any) {
    if (this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'toolResponse', data }));
    }
  }

  close() {
    this.ws.close();
  }
}

type Topic = {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
};

type QuizQuestion = {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
};

function getFetchHeaders(): Record<string, string> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  const savedKey = localStorage.getItem('user_gemini_api_key');
  if (savedKey) {
    headers["x-gemini-api-key"] = savedKey;
  }
  return headers;
}

export default function App() {
  const [files, setFiles] = useState<File[]>([]);
  const [isExtracting, setIsExtracting] = useState(false);
  const [studyText, setStudyText] = useState<string>('');
  const [fileTexts, setFileTexts] = useState<Record<string, string>>({});
  const [activeFileNames, setActiveFileNames] = useState<string[]>([]);
  
  const [topics, setTopics] = useState<Topic[]>([]);
  const [isGeneratingTopics, setIsGeneratingTopics] = useState(false);
  const [viewMode, setViewMode] = useState<'setup' | 'visual' | 'session' | 'free_session' | 'multiple_choice'>('setup');
  const [unlockedTopics, setUnlockedTopics] = useState<string[]>([]);
  const [savedQuizQuestions, setSavedQuizQuestions] = useState<QuizQuestion[]>([]);
  const [quizVersion, setQuizVersion] = useState(0);

  const [userTier, setUserTier] = useState<'free' | 'pro'>(() => {
    return (localStorage.getItem('user_tier') as 'free' | 'pro') || 'free';
  });
  const [showBillingModal, setShowBillingModal] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'select' | 'pay' | 'processing' | 'success'>('select');
  const [billingTab, setBillingTab] = useState<'plans' | 'monetize'>('plans');
  const [cardName, setCardName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');

  // Estados para simulación y configuración de Cafecito/Donaciones
  const [coffeeLink, setCoffeeLink] = useState(() => {
    return localStorage.getItem('creator_coffee_link') || 'https://link.mercadopago.com.ar/martinmano';
  });
  const [creatorAlias, setCreatorAlias] = useState(() => {
    return localStorage.getItem('creator_alias') || 'martinmano';
  });
  const [showCoffeeModal, setShowCoffeeModal] = useState(false);
  const [isEditingCoffeeLink, setIsEditingCoffeeLink] = useState(false);
  const [tempCoffeeLink, setTempCoffeeLink] = useState(coffeeLink);
  const [tempCreatorAlias, setTempCreatorAlias] = useState(creatorAlias);

  const handleSaveCoffeeLink = () => {
    localStorage.setItem('creator_coffee_link', tempCoffeeLink);
    localStorage.setItem('creator_alias', tempCreatorAlias);
    setCoffeeLink(tempCoffeeLink);
    setCreatorAlias(tempCreatorAlias);
    setIsEditingCoffeeLink(false);
  };

  useEffect(() => {
    if (showBillingModal) {
      setPaymentStep('select');
      setBillingTab('plans');
      setCardName('');
      setCardNumber('');
      setCardExpiry('');
      setCardCvc('');
    }
  }, [showBillingModal]);

  const handleUpgradeToPro = () => {
    localStorage.setItem('user_tier', 'pro');
    setUserTier('pro');
  };

  const handleResetTier = () => {
    localStorage.setItem('user_tier', 'free');
    setUserTier('free');
  };

  const [isKeyMissing, setIsKeyMissing] = useState(false);
  const [isCheckedEnv, setIsCheckedEnv] = useState(false);
  const [showKeyInstructions, setShowKeyInstructions] = useState(false);
  const [userApiKey, setUserApiKey] = useState<string>(() => localStorage.getItem('user_gemini_api_key') || '');
  const [tempApiKey, setTempApiKey] = useState(() => localStorage.getItem('user_gemini_api_key') || '');

  const handleSaveApiKey = (key: string) => {
    const trimmed = key.trim();
    if (trimmed) {
      localStorage.setItem('user_gemini_api_key', trimmed);
      setUserApiKey(trimmed);
      setTempApiKey(trimmed);
      alert("🎉 ¡Clave API guardada correctamente en este navegador! Ya puedes usar la aplicación.");
    } else {
      handleClearApiKey();
    }
  };

  const handleClearApiKey = () => {
    localStorage.removeItem('user_gemini_api_key');
    setUserApiKey('');
    setTempApiKey('');
    alert("Clave API eliminada de este navegador.");
  };

  // --- USER IDENTIFICATION & HISTORY SYSTEM ---
  const [userEmail, setUserEmail] = useState<string | null>(() => localStorage.getItem('user_email') || null);
  const [userDisplayName, setUserDisplayName] = useState<string | null>(() => localStorage.getItem('user_display_name') || null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [userHistory, setUserHistory] = useState<any[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [activeStudyId, setActiveStudyId] = useState<string | null>(null);
  const [activeStudyTitle, setActiveStudyTitle] = useState<string>('');
  const [showSaveStudyModal, setShowSaveStudyModal] = useState(false);
  const [newStudyTitle, setNewStudyTitle] = useState('');
  const [tempEmailInput, setTempEmailInput] = useState('');
  const [tempNameInput, setTempNameInput] = useState('');
  const [isSimulatingGoogle, setIsSimulatingGoogle] = useState(false);

  const handleCreateNewNotebook = () => {
    if (userTier === 'free' && userHistory.length >= 2) {
      alert("⚠️ Has alcanzado el límite de 2 cuadernos de estudio en tu cuenta gratuita. Por favor, actualiza a PRO para crear cuadernos ilimitados.");
      setShowBillingModal(true);
      return;
    }
    setFiles([]);
    setFileTexts({});
    setActiveFileNames([]);
    setStudyText('');
    setTopics([]);
    setUnlockedTopics([]);
    setSavedQuizQuestions([]);
    setQuizVersion(v => v + 1);
    setActiveStudyId(null);
    setActiveStudyTitle('');
    setNewStudyTitle('');
    setViewMode('setup');
  };

  const fetchUserHistory = async (email: string) => {
    setIsLoadingHistory(true);
    try {
      const res = await fetch(`/api/history?email=${encodeURIComponent(email)}`);
      if (res.ok) {
        const data = await res.json();
        setUserHistory(data.studies || []);
      }
    } catch (err) {
      console.error("Error fetching user history:", err);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const saveCurrentStudy = async (
    titleToSave: string, 
    silent: boolean = false, 
    customFields?: { 
      topics?: Topic[]; 
      unlockedTopics?: string[]; 
      savedQuizQuestions?: QuizQuestion[]; 
    }
  ) => {
    if (!userEmail) {
      if (!silent) {
        setShowAuthModal(true);
      }
      return;
    }
    
    // Si es un cuaderno nuevo (no tiene activeStudyId) y el usuario ya tiene 2 o más cuadernos guardados
    if (userTier === 'free' && !activeStudyId && userHistory.length >= 2) {
      if (!silent) {
        alert("⚠️ Has alcanzado el límite de 2 cuadernos de estudio en tu cuenta gratuita. Por favor, actualiza a PRO para guardar cuadernos ilimitados.");
        setShowBillingModal(true);
      }
      return;
    }
    
    const studyId = activeStudyId || `study_${Date.now()}`;
    const cleanTitle = titleToSave.trim() || activeStudyTitle || `Estudio del ${new Date().toLocaleDateString('es-AR')}`;
    
    const currentTopics = customFields?.topics !== undefined ? customFields.topics : topics;
    const currentUnlocked = customFields?.unlockedTopics !== undefined ? customFields.unlockedTopics : unlockedTopics;
    const currentQuiz = customFields?.savedQuizQuestions !== undefined ? customFields.savedQuizQuestions : savedQuizQuestions;

    const newStudy = {
      id: studyId,
      title: cleanTitle,
      files: files.map(f => ({ name: f.name, size: f.size, type: f.type })),
      studyText: studyText,
      fileTexts: fileTexts,
      activeFileNames: activeFileNames,
      topics: currentTopics,
      unlockedTopics: currentUnlocked,
      savedQuizQuestions: currentQuiz,
      viewMode: viewMode,
      createdAt: new Date().toISOString()
    };

    try {
      const res = await fetch("/api/history", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: userEmail, study: newStudy })
      });
      if (res.ok) {
        setActiveStudyId(studyId);
        setActiveStudyTitle(newStudy.title);
        fetchUserHistory(userEmail);
        setShowSaveStudyModal(false);
      } else {
        if (!silent) {
          alert("No se pudo guardar en el servidor.");
        }
      }
    } catch (err) {
      console.error("Error saving study:", err);
      if (!silent) {
        alert("Error al conectar con el servidor.");
      }
    }
  };

  const deleteStudyFromHistory = async (studyId: string, title: string) => {
    if (!userEmail) return;
    if (!confirm(`¿Estás seguro de que quieres eliminar "${title}" de tu historial?`)) return;

    try {
      const res = await fetch("/api/history", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: userEmail, studyId })
      });
      if (res.ok) {
        if (activeStudyId === studyId) {
          setActiveStudyId(null);
          setActiveStudyTitle('');
        }
        fetchUserHistory(userEmail);
      } else {
        alert("No se pudo eliminar el estudio.");
      }
    } catch (err) {
      console.error("Error deleting study:", err);
    }
  };

  const loadStudy = (study: any) => {
    const virtualFiles = study.files.map((f: any) => {
      return new File([], f.name, { type: f.type || 'application/pdf' });
    });
    
    setFiles(virtualFiles);
    
    // Load fileTexts and activeFileNames with backwards-compatible fallback
    const loadedFileTexts = study.fileTexts || {};
    const loadedActiveFileNames = study.activeFileNames || study.files.map((f: any) => f.name);
    
    if (Object.keys(loadedFileTexts).length === 0 && study.studyText) {
      const parts = study.studyText.split(/--- Documento: (.+?) ---/g);
      for (let index = 1; index < parts.length; index += 2) {
        const name = parts[index]?.trim();
        const text = parts[index + 1]?.trim();
        if (name && text) {
          loadedFileTexts[name] = text;
        }
      }
      
      if (Object.keys(loadedFileTexts).length === 0 && virtualFiles.length > 0) {
        loadedFileTexts[virtualFiles[0].name] = study.studyText;
      }
    }
    
    setFileTexts(loadedFileTexts);
    setActiveFileNames(loadedActiveFileNames);
    
    setStudyText(study.studyText || '');
    setTopics(study.topics || []);
    setUnlockedTopics(study.unlockedTopics || []);
    setSavedQuizQuestions(study.savedQuizQuestions || []);
    setQuizVersion(v => v + 1);
    setViewMode(study.viewMode || 'visual');
    setActiveStudyId(study.id);
    setActiveStudyTitle(study.title);
  };

  const handleIdentifyUser = (email: string, name?: string) => {
    const trimmedEmail = email.trim();
    if (!trimmedEmail) return;

    const displayName = name || trimmedEmail.split('@')[0];
    
    localStorage.setItem('user_email', trimmedEmail);
    localStorage.setItem('user_display_name', displayName);
    setUserEmail(trimmedEmail);
    setUserDisplayName(displayName);
    
    fetchUserHistory(trimmedEmail);
    setShowAuthModal(false);
  };

  const handleSignOut = () => {
    localStorage.removeItem('user_email');
    localStorage.removeItem('user_display_name');
    setUserEmail(null);
    setUserDisplayName(null);
    setUserHistory([]);
    setActiveStudyId(null);
    setActiveStudyTitle('');
  };

  useEffect(() => {
    if (userEmail) {
      fetchUserHistory(userEmail);
    }
  }, [userEmail]);

  useEffect(() => {
    const verifyEnv = async () => {
      try {
        const res = await fetch("/api/check-env");
        if (res.ok) {
          const data = await res.json();
          const missing = !data.gemini_key_present;
          setIsKeyMissing(missing);
          if (missing) {
            setShowKeyInstructions(true);
          }
        }
      } catch (err) {
        console.error("Error checking environment:", err);
      } finally {
        setIsCheckedEnv(true);
      }
    };
    verifyEnv();
  }, [viewMode]);

  const handleFileDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const droppedFiles = Array.from(e.dataTransfer.files) as File[];
    await addFiles(droppedFiles);
  };

  const handleFileInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files) as File[];
      await addFiles(selectedFiles);
    }
  };

  const rebuildStudyText = (currentFiles: File[], currentActiveNames: string[], currentFileTexts: Record<string, string>) => {
    let combinedText = '';
    for (const file of currentFiles) {
      if (currentActiveNames.includes(file.name)) {
        const text = currentFileTexts[file.name] || '';
        combinedText += `\n\n--- Documento: ${file.name} ---\n\n${text}`;
      }
    }
    setStudyText(combinedText);
  };

  const toggleFileActive = (fileName: string) => {
    const isCurrentlyActive = activeFileNames.includes(fileName);
    let newActiveFileNames: string[];
    if (isCurrentlyActive) {
      newActiveFileNames = activeFileNames.filter(name => name !== fileName);
    } else {
      newActiveFileNames = [...activeFileNames, fileName];
    }
    setActiveFileNames(newActiveFileNames);
    rebuildStudyText(files, newActiveFileNames, fileTexts);
  };

  const addFiles = async (newFiles: File[]) => {
    if (userTier === 'free' && !activeStudyId && userHistory.length >= 2) {
      alert("⚠️ Has alcanzado el límite de 2 cuadernos de estudio en tu cuenta gratuita. Por favor, actualiza a PRO para crear y usar más cuadernos.");
      setShowBillingModal(true);
      return;
    }

    const validFiles = newFiles.filter(f => 
      f.type === 'application/pdf' || 
      f.type.startsWith('text/') || 
      f.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
      f.type === 'application/msword' ||
      f.name.toLowerCase().endsWith('.md') || 
      f.name.toLowerCase().endsWith('.txt') ||
      f.name.toLowerCase().endsWith('.csv') ||
      f.name.toLowerCase().endsWith('.docx') ||
      f.name.toLowerCase().endsWith('.doc')
    );

    if (validFiles.length === 0) {
      alert('Por favor, sube archivos válidos (PDF, Word o Texto).');
      return;
    }

    if (userTier === 'free' && (files.length + validFiles.length) > 2) {
      setShowBillingModal(true);
      alert('⚠️ Límite del plan gratuito alcanzado. El plan gratuito está limitado a un máximo de 2 documentos simultáneos. ¡Mejora tu cuenta a PRO para subidas ilimitadas!');
      return;
    }

    setIsExtracting(true);
    try {
      const newFileTexts = { ...fileTexts };
      const newActiveFileNames = [...activeFileNames];
      const successfullyExtractedFiles: File[] = [];
      
      for (const file of validFiles) {
        try {
          const text = await extractTextFromFile(file);
          newFileTexts[file.name] = text;
          if (!newActiveFileNames.includes(file.name)) {
            newActiveFileNames.push(file.name);
          }
          successfullyExtractedFiles.push(file);
        } catch (fileError: any) {
          console.error(`Error extracting file ${file.name}:`, fileError);
          alert(`Error al procesar "${file.name}":\n${fileError.message || fileError}`);
        }
      }
      
      if (successfullyExtractedFiles.length > 0) {
        const updatedFiles = [...files, ...successfullyExtractedFiles];
        setFiles(updatedFiles);
        setFileTexts(newFileTexts);
        setActiveFileNames(newActiveFileNames);
        rebuildStudyText(updatedFiles, newActiveFileNames, newFileTexts);
      }
    } catch (error: any) {
      console.error('Error extracting text:', error);
      alert(`Hubo un error al procesar los archivos:\n${error.message || error}`);
    } finally {
      setIsExtracting(false);
    }
  };

  const removeFile = (indexToRemove: number) => {
    const fileToRemove = files[indexToRemove];
    const remainingFiles = files.filter((_, index) => index !== indexToRemove);
    setFiles(remainingFiles);
    
    const newFileTexts = { ...fileTexts };
    if (fileToRemove) {
      delete newFileTexts[fileToRemove.name];
    }
    const newActiveFileNames = activeFileNames.filter(name => name !== fileToRemove?.name);
    
    setFileTexts(newFileTexts);
    setActiveFileNames(newActiveFileNames);
    rebuildStudyText(remainingFiles, newActiveFileNames, newFileTexts);
    
    if (remainingFiles.length === 0) {
      setTopics([]);
    }
  };

  const reprocessFiles = async (filesToProcess: File[]) => {
    // Left for potential old compatibility, no longer primary
    if (filesToProcess.length === 0) {
      setStudyText('');
      setTopics([]);
      return;
    }
    setIsExtracting(true);
    try {
      const newFileTexts = { ...fileTexts };
      const newActiveFileNames = [...activeFileNames];
      for (const file of filesToProcess) {
        if (!newFileTexts[file.name]) {
          const text = await extractTextFromFile(file);
          newFileTexts[file.name] = text;
        }
        if (!newActiveFileNames.includes(file.name)) {
          newActiveFileNames.push(file.name);
        }
      }
      setFileTexts(newFileTexts);
      setActiveFileNames(newActiveFileNames);
      rebuildStudyText(filesToProcess, newActiveFileNames, newFileTexts);
    } catch (error) {
      console.error('Error extracting text:', error);
    } finally {
      setIsExtracting(false);
    }
  };

  const generateTopics = async () => {
    setIsGeneratingTopics(true);
    try {
      const res = await fetch("/api/generate-topics", {
        method: "POST",
        headers: getFetchHeaders(),
        body: JSON.stringify({ studyText }),
      });
      if (!res.ok) {
        let errorMsg = `Server returned status ${res.status}`;
        try {
          const errData = await res.json();
          if (errData && errData.error) {
            errorMsg = errData.error;
          }
        } catch (_) {}
        throw new Error(errorMsg);
      }
      const data = await res.json();
      
      const parsed = JSON.parse(data.text || '[]');
      const generatedTopics = parsed.map((t: any) => ({
        id: t.id,
        title: t.title,
        description: t.description,
        imageUrl: `https://image.pollinations.ai/prompt/${encodeURIComponent(t.imagePrompt)}?width=400&height=300&nologo=true`
      }));
      
      setTopics(generatedTopics);
      setViewMode('visual');
      if (activeStudyId) {
        saveCurrentStudy(activeStudyTitle, true, { topics: generatedTopics });
      }
    } catch (error: any) {
      console.error('Error generating topics:', error);
      alert(error.message || 'Hubo un error al generar los temas.');
    } finally {
      setIsGeneratingTopics(false);
    }
  };

  const startQuiz = () => {
    setUnlockedTopics([]);
    setViewMode('session');
    if (activeStudyId) {
      saveCurrentStudy(activeStudyTitle, true, { unlockedTopics: [] });
    }
  };

  const handleUnlockTopic = (topicId: string) => {
    setUnlockedTopics(prev => {
      if (!prev.includes(topicId)) {
        const next = [...prev, topicId];
        if (activeStudyId) {
          saveCurrentStudy(activeStudyTitle, true, { unlockedTopics: next });
        }
        return next;
      }
      return prev;
    });
  };

  return (
    <div className="min-h-screen bg-bg-systematic text-ink font-sans selection:bg-accent-systematic selection:text-black flex flex-col h-screen overflow-hidden">
      {/* Top Header for Mobile & Tablet */}
      <header className="lg:hidden bg-panel-systematic border-b border-white/5 px-6 py-4 flex items-center justify-between z-30 shrink-0">
        <div className="flex items-center gap-2">
          <div className="font-display font-black text-lg uppercase tracking-tighter">
            Tutor <span className="text-accent-systematic">Cuaderno</span>
          </div>
          {userTier === 'pro' ? (
            <span className="font-mono text-[8px] bg-amber-500/20 text-amber-500 px-1.5 py-0.5 rounded border border-amber-500/30 uppercase font-bold tracking-widest">
              ★ {userDisplayName ? `${userDisplayName} Pro` : 'PRO'}
            </span>
          ) : (
            <button
              onClick={() => setShowBillingModal(true)}
              className="font-mono text-[8px] bg-accent-systematic text-black px-1.5 py-0.5 rounded uppercase font-bold tracking-widest animate-pulse cursor-pointer"
            >
              PRO
            </button>
          )}
          <span className="font-mono text-[8px] bg-white/10 text-ink px-1.5 py-0.5 rounded uppercase font-bold tracking-widest">
            {viewMode}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {userEmail ? (
            <button
              onClick={handleSignOut}
              className="font-mono text-[8px] border border-red-500/25 px-2 py-1 text-red-400 uppercase tracking-wider hover:bg-red-500/10 transition-colors cursor-pointer"
              title={`Identificado como: ${userEmail}. Clic para cerrar sesión.`}
            >
              Cerrar ({userDisplayName ? userDisplayName.substring(0, 6) : 'Est.'})
            </button>
          ) : (
            <button
              onClick={() => {
                setTempEmailInput('');
                setTempNameInput('');
                setShowAuthModal(true);
              }}
              className="font-mono text-[8px] bg-emerald-500/90 text-black px-2.5 py-1 uppercase tracking-wider font-bold transition-all cursor-pointer hover:bg-emerald-400"
            >
              Ingresar
            </button>
          )}
          <button
            onClick={() => setShowKeyInstructions(!showKeyInstructions)}
            className="font-mono text-[8px] border border-white/10 px-2.5 py-1 text-ink uppercase tracking-wider hover:bg-white hover:text-black transition-colors"
          >
            Clave API
          </button>
          {viewMode !== 'setup' && (
            <button
              onClick={() => setViewMode('setup')}
              className="font-mono text-[8px] bg-accent-systematic text-black px-2.5 py-1 uppercase tracking-wider font-bold transition-all"
            >
              Volver
            </button>
          )}
        </div>
      </header>

      {/* Main Full-Screen Layout */}
      <div className="flex-grow flex flex-col lg:flex-row overflow-hidden relative">
        {/* Nav Rail (hidden on mobile) */}
        <div className="hidden lg:flex w-20 flex-col items-center py-8 border-r border-white/5 shrink-0 select-none bg-bg-systematic">
          <div className="w-10 h-10 border border-ink mb-6 flex items-center justify-center font-mono text-sm font-bold tracking-tighter">T</div>
          <div className={cn(
            "w-10 h-10 border mb-6 flex items-center justify-center font-mono text-sm tracking-tighter transition-all duration-300",
            viewMode === 'free_session' ? "border-accent-systematic text-accent-systematic font-bold" : "border-white/10 opacity-30"
          )}>C</div>
          <div className={cn(
            "w-10 h-10 border mb-6 flex items-center justify-center font-mono text-sm tracking-tighter transition-all duration-300",
            viewMode === 'multiple_choice' ? "border-accent-systematic text-accent-systematic font-bold" : "border-white/10 opacity-30"
          )}>V</div>
        </div>

        {/* Left Sidebar (hidden on mobile) */}
        <aside className="hidden lg:flex w-72 flex-col bg-panel-systematic p-8 border-r border-white/5 shrink-0 select-none overflow-y-auto">
          <div className="logo-text font-display font-black text-2xl uppercase tracking-tighter leading-none mb-10">
            Tutor<br />
            <span className="text-accent-systematic">Cuaderno</span>
          </div>

          {/* Tarjeta de Suscripción PRO / Premium */}
          <div className="mb-8 border border-white/5 bg-bg-systematic/50 p-4 rounded-xl flex flex-col relative overflow-hidden group">
            {userTier === 'pro' ? (
              <>
                <div className="absolute top-0 right-0 bg-amber-500/10 text-amber-400 text-[8px] font-mono font-bold uppercase tracking-widest px-2.5 py-1 border-b border-l border-white/5 rounded-bl-xl">
                  ★ {userDisplayName ? `${userDisplayName} Pro` : 'PRO'}
                </div>
                <span className="font-mono text-[9px] text-amber-500 uppercase tracking-widest block mb-1 font-bold">Plan de Cuenta</span>
                <h4 className="text-sm font-bold text-ink uppercase tracking-tight flex items-center gap-1.5">
                  Suscripción Activa
                </h4>
                <p className="text-[10px] text-ink-muted leading-relaxed mt-1.5 mb-3">
                  Tienes acceso ilimitado a documentos, cuestionarios y tutorías de voz.
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowBillingModal(true)}
                    className="w-full text-center py-2 border border-white/10 hover:border-white/20 text-[9px] font-mono uppercase tracking-widest font-bold text-ink bg-transparent cursor-pointer transition-colors"
                  >
                    Detalles del Plan
                  </button>
                  <button
                    onClick={handleResetTier}
                    className="px-2 text-center border border-red-900/30 hover:bg-red-950/20 text-[9px] font-mono text-red-400 bg-transparent cursor-pointer transition-colors"
                    title="Restablecer para demostración"
                  >
                    Reset
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="absolute top-0 right-0 bg-accent-systematic/10 text-accent-systematic text-[8px] font-mono font-bold uppercase tracking-widest px-2 px-1 border-b border-l border-white/5 rounded-bl-xl">
                  GRATIS
                </div>
                <span className="font-mono text-[9px] text-ink-muted uppercase tracking-widest block mb-1">Plan de Cuenta</span>
                <h4 className="text-sm font-bold text-ink uppercase tracking-tight">
                  Tutor Cuaderno Free
                </h4>
                <div className="w-full bg-white/5 rounded-full h-1 my-2 overflow-hidden">
                  <div 
                    className="bg-accent-systematic h-full transition-all duration-300"
                    style={{ width: `${Math.min((files.length / 2) * 100, 100)}%` }}
                  />
                </div>
                <p className="text-[10px] text-ink-muted leading-relaxed mb-3">
                  Uso: <span className="text-white font-bold">{files.length}</span> de <span className="text-accent-systematic font-bold">2</span> documentos permitidos.
                </p>
                <button
                  onClick={() => setShowBillingModal(true)}
                  className="w-full text-center py-2.5 bg-accent-systematic text-black hover:bg-white text-[9px] font-mono uppercase tracking-widest font-bold transition-all duration-200 cursor-pointer mb-2"
                >
                  Mejorar a PRO ($2.99 USD/mes)
                </button>
                <button
                  onClick={() => {
                    setTempCoffeeLink(coffeeLink);
                    setTempCreatorAlias(creatorAlias);
                    setShowCoffeeModal(true);
                  }}
                  className="w-full text-center py-1.5 border border-white/5 hover:border-white/20 text-[8px] font-mono uppercase tracking-widest text-ink-muted hover:text-white transition-all cursor-pointer bg-transparent"
                >
                  💳 Apoyar con Mercado Pago
                </button>
              </>
            )}
          </div>

          {/* Identificación del Estudiante */}
          <div className="mb-6 border border-white/5 bg-zinc-950/40 p-4 rounded-xl flex flex-col relative overflow-hidden group">
            {userEmail ? (
              <>
                <div className="absolute top-0 right-0 bg-emerald-500/10 text-emerald-400 text-[8px] font-mono font-bold uppercase tracking-widest px-2.5 py-1 border-b border-l border-white/5 rounded-bl-xl">
                  ✓ ONLINE
                </div>
                <span className="font-mono text-[9px] text-emerald-500 uppercase tracking-widest block mb-1 font-bold">Estudiante</span>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center font-bold text-emerald-400 text-xs shrink-0">
                    {userDisplayName ? userDisplayName[0].toUpperCase() : 'U'}
                  </div>
                  <div className="overflow-hidden">
                    <h4 className="text-xs font-bold text-ink uppercase tracking-tight truncate">
                      {userDisplayName}
                    </h4>
                    <p className="text-[9px] text-ink-muted truncate">
                      {userEmail}
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleSignOut}
                  className="w-full text-center py-1.5 border border-red-500/10 hover:border-red-500/20 text-[8px] font-mono uppercase tracking-widest text-red-400/80 hover:text-red-400 transition-all cursor-pointer bg-transparent mt-1 font-medium"
                >
                  Cerrar Sesión
                </button>
              </>
            ) : (
              <>
                <span className="font-mono text-[9px] text-ink-muted uppercase tracking-widest block mb-1">Identificación</span>
                <h4 className="text-xs font-bold text-ink uppercase tracking-tight mb-2">
                  Guarda tu Historial
                </h4>
                <p className="text-[10px] text-ink-muted leading-relaxed mb-3">
                  Identifícate con tu Email o Google para guardar tus cuadernos y progreso en la nube.
                </p>
                <button
                  onClick={() => {
                    setTempEmailInput('');
                    setTempNameInput('');
                    setShowAuthModal(true);
                  }}
                  className="w-full text-center py-2 bg-emerald-500 hover:bg-emerald-400 text-black text-[9px] font-mono uppercase tracking-widest font-bold transition-all duration-200 cursor-pointer"
                >
                  Ingresar / Registrarme
                </button>
              </>
            )}
          </div>

          {/* Estado de Carga / Guardado de Cuaderno Activo */}
          {files.length > 0 && studyText.trim() !== '' && (
            <div className="mb-6 p-4 bg-zinc-950/40 border border-emerald-500/15 rounded-xl space-y-2">
              <div>
                <span className="font-mono text-[8px] text-emerald-400 uppercase tracking-widest block mb-1 font-bold">Estado del Cuaderno</span>
                <h4 className="text-xs font-bold text-white uppercase tracking-tight truncate">
                  {activeStudyTitle || "Cuaderno sin Guardar"}
                </h4>
              </div>
              <button
                onClick={() => {
                  if (!userEmail) {
                    setShowAuthModal(true);
                  } else {
                    setNewStudyTitle(activeStudyTitle || "");
                    setShowSaveStudyModal(true);
                  }
                }}
                className="w-full py-2 bg-emerald-500 text-black font-mono font-bold text-[9px] uppercase tracking-wider rounded transition-all hover:bg-emerald-400 cursor-pointer flex items-center justify-center gap-1.5 border-none"
              >
                <span>💾 {activeStudyId ? "Actualizar Guardado" : "Guardar en Historial"}</span>
              </button>
              
              <button
                onClick={handleCreateNewNotebook}
                className="w-full py-1.5 border border-white/10 hover:border-white/20 text-white font-mono font-bold text-[9px] uppercase tracking-wider rounded transition-all hover:bg-white/5 cursor-pointer flex items-center justify-center gap-1 bg-transparent"
              >
                <span>✨ Crear Nuevo Cuaderno</span>
              </button>
            </div>
          )}

          <span className="font-mono text-[9px] text-ink-muted uppercase tracking-widest block mb-4">Modos de Estudio</span>
          <div className="space-y-3">
            <button
              disabled={files.length === 0 || isExtracting}
              onClick={() => setViewMode('free_session')}
              className={cn(
                "w-full text-left p-5 border transition-all duration-300 group cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed",
                viewMode === 'free_session' 
                  ? "border-accent-systematic bg-accent-systematic/5 text-ink" 
                  : "border-white/5 hover:border-white/20 bg-transparent text-white"
              )}
            >
              <h4 className="font-mono font-bold text-[10px] tracking-wider uppercase mb-1 flex items-center gap-1.5">
                <span className={cn("w-1.5 h-1.5 rounded-full", viewMode === 'free_session' ? "bg-accent-systematic" : "bg-white/20")}></span>
                [01] TUTORÍA_LIBRE
              </h4>
              <p className="text-[10px] text-ink-muted leading-relaxed">
                Conversación abierta de voz sobre el contenido.
              </p>
            </button>

            <button
              disabled={files.length === 0 || isExtracting}
              onClick={() => setViewMode('multiple_choice')}
              className={cn(
                "w-full text-left p-5 border transition-all duration-300 group cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed",
                viewMode === 'multiple_choice' 
                  ? "border-accent-systematic bg-accent-systematic/5 text-ink" 
                  : "border-white/5 hover:border-white/20 bg-transparent text-white"
              )}
            >
              <h4 className="font-mono font-bold text-[10px] tracking-wider uppercase mb-1 flex items-center gap-1.5">
                <span className={cn("w-1.5 h-1.5 rounded-full", viewMode === 'multiple_choice' ? "bg-accent-systematic" : "bg-white/20")}></span>
                [02] TEST_DINÁMICO
              </h4>
              <p className="text-[10px] text-ink-muted leading-relaxed">
                Cuestionario de retención progresiva.
              </p>
            </button>

            <button
              disabled={files.length === 0 || isExtracting || isGeneratingTopics}
              onClick={generateTopics}
              className={cn(
                "w-full text-left p-5 border transition-all duration-300 group cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed",
                viewMode === 'visual' || viewMode === 'session'
                  ? "border-accent-systematic bg-accent-systematic/5 text-ink" 
                  : "border-white/5 hover:border-white/20 bg-transparent text-white"
              )}
            >
              <h4 className="font-mono font-bold text-[10px] tracking-wider uppercase mb-1 flex items-center gap-1.5">
                <span className={cn("w-1.5 h-1.5 rounded-full", viewMode === 'visual' || viewMode === 'session' ? "bg-accent-systematic" : "bg-white/20")}></span>
                [03] FLASHCARDS_VOZ
              </h4>
              <p className="text-[10px] text-ink-muted leading-relaxed">
                Tarjetas conceptuales guiadas vía voz.
              </p>
            </button>

            <button
              onClick={() => setViewMode('setup')}
              className={cn(
                "w-full text-left p-5 border transition-all duration-300 group cursor-pointer",
                viewMode === 'setup' 
                  ? "border-accent-systematic bg-accent-systematic/5 text-ink" 
                  : "border-white/5 hover:border-white/20 bg-transparent text-white"
              )}
            >
              <h4 className="font-mono font-bold text-[10px] tracking-wider uppercase mb-1 flex items-center gap-1.5">
                <span className={cn("w-1.5 h-1.5 rounded-full", viewMode === 'setup' ? "bg-accent-systematic" : "bg-white/20")}></span>
                [00] FUENTES_CUADERNO
              </h4>
              <p className="text-[10px] text-ink-muted leading-relaxed">
                Configuración y carga de documentos.
              </p>
            </button>
          </div>

          <div className="mt-auto pt-6 border-t border-white/5">
            <span className="font-mono text-[9px] text-ink-muted uppercase tracking-widest block mb-1">Estado de Seguridad</span>
            <div className="font-mono text-[10px] text-accent-systematic font-bold uppercase tracking-wider">CANAL_SEGURO_ACTIVADO</div>
          </div>
        </aside>

        {/* Main Viewport */}
        <main className="flex-grow flex flex-col overflow-y-auto grid-bg relative p-6 lg:p-12 z-10">
        {/* Banner de Guía y Estado de API Key */}
        {((isCheckedEnv && isKeyMissing) || showKeyInstructions) && (
          <div className={cn(
            "mb-8 rounded-2xl p-6 border transition-all shadow-sm",
            isKeyMissing && !userApiKey
              ? "bg-amber-50 border-amber-200 text-slate-800" 
              : "bg-indigo-50 border-indigo-150 text-slate-800"
          )}>
            <div className="flex flex-col md:flex-row gap-4 items-start justify-between">
              <div className="flex gap-4 items-start">
                <div className={cn(
                  "p-3 rounded-xl shrink-0",
                  isKeyMissing && !userApiKey ? "bg-amber-100 text-amber-800" : "bg-indigo-100 text-indigo-800"
                )}>
                  {isKeyMissing && !userApiKey ? <AlertTriangle className="w-6 h-6" /> : <Key className="w-6 h-6" />}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    {isKeyMissing && !userApiKey 
                      ? "Clave API de Gemini No Configurada" 
                      : isKeyMissing && userApiKey 
                        ? "Usando Clave API de Gemini del Navegador" 
                        : "Guía de Conexión y Seguridad de Claves"}
                  </h3>
                  <p className="text-slate-600 text-sm mt-1 leading-relaxed">
                    {isKeyMissing && !userApiKey 
                      ? "Esta aplicación está compartida y requiere tu clave API de Gemini para procesar documentos y usar el tutor por voz. Pégala abajo para comenzar gratis."
                      : isKeyMissing && userApiKey 
                        ? "Has configurado tu clave de API personal en este navegador. Tus documentos y sesiones de voz funcionarán perfectamente."
                        : "Tu clave de API de Gemini está configurada correctamente y lista para interactuar con el tutor de voz."}
                  </p>
                </div>
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  onClick={() => setShowKeyInstructions(!showKeyInstructions)}
                  className={cn(
                    "font-semibold px-4 py-2 rounded-xl text-sm transition-all shadow-sm flex items-center gap-2",
                    isKeyMissing && !userApiKey 
                      ? "bg-amber-600 hover:bg-amber-700 text-white" 
                      : "bg-indigo-600 hover:bg-indigo-700 text-white"
                  )}
                >
                  <HelpCircle className="w-4 h-4" />
                  {showKeyInstructions ? "Ocultar Instrucciones" : "Ver Instrucciones Paso a Paso"}
                </button>
                {isKeyMissing && !userApiKey && (
                  <button
                    onClick={() => setIsKeyMissing(false)}
                    className="bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 px-3 py-2 rounded-xl text-sm transition-all shadow-sm font-semibold"
                  >
                    Ocultar aviso
                  </button>
                )}
              </div>
            </div>

            {/* Input fields to enter custom API key */}
            {isKeyMissing && (
              <div className="mt-6 border-t border-slate-200 pt-6 max-w-2xl">
                <h4 className="font-bold text-slate-900 mb-2 text-sm uppercase tracking-wider flex items-center gap-2">
                  <Key className="w-4 h-4 text-indigo-600" />
                  Configurar tu Clave de API de Gemini Personalizada (Para Invitados)
                </h4>
                <p className="text-slate-500 text-xs mb-4 leading-relaxed">
                  Pega tu clave aquí. Se guardará de forma local y 100% privada únicamente en la memoria de este navegador web (<code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800 font-mono">localStorage</code>). Nunca se enviará ni guardará en un servidor de terceros.
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="password"
                    value={tempApiKey}
                    onChange={(e) => setTempApiKey(e.target.value)}
                    placeholder="Pega tu clave API aquí (ej. AIzaSy...)"
                    className="flex-grow bg-white border border-slate-300 rounded-xl px-4 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleSaveApiKey(tempApiKey)}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-xl text-xs font-semibold shadow-sm transition-all whitespace-nowrap"
                    >
                      Guardar Clave
                    </button>
                    {userApiKey && (
                      <button
                        onClick={handleClearApiKey}
                        className="bg-red-50 hover:bg-red-100 text-red-600 border border-red-100 px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap"
                      >
                        Eliminar Clave
                      </button>
                    )}
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-1.5 text-xs text-indigo-600">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>¿No tienes una clave? Consíguela gratis en un clic en <a href="https://aistudio.google.com/" target="_blank" rel="noopener noreferrer" className="underline font-bold hover:text-indigo-800">Google AI Studio</a>.</span>
                </div>
              </div>
            )}

            {showKeyInstructions && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="mt-6 border-t border-slate-200 pt-6 text-slate-700"
              >
                <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2 text-sm uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  ¿Cómo funciona este sistema y qué pasa al publicarlo?
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm mb-6">
                  <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-xs">
                    <h5 className="font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                      <Lock className="w-4 h-4 text-indigo-500" />
                      🔑 En Desarrollo (Para ti):
                    </h5>
                    <p className="text-slate-600 leading-relaxed text-xs">
                      AI Studio ejecuta tu aplicación en un contenedor seguro. Tus claves nunca se escriben directamente en el código; se guardan de forma encriptada en el panel de **Settings &gt; Secrets** (Configuración &gt; Secretos) de AI Studio y se inyectan como variables de entorno privadas.
                    </p>
                  </div>
                  <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-xs">
                    <h5 className="font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                      <Unlock className="w-4 h-4 text-emerald-500" />
                      🚀 Al Publicar o Compartir:
                    </h5>
                    <p className="text-slate-600 leading-relaxed text-xs">
                      ¡Tu clave de API está 100% segura! Cuando otra persona use tu app compartida, la plataforma de Google AI Studio **le solicitará de forma segura que introduzca su propia clave API**. De esta forma, **nadie más podrá usar ni ver tu clave de API personal**, y cada usuario consumirá sus propios límites.
                    </p>
                  </div>
                </div>

                <h4 className="font-semibold text-slate-900 mb-3 text-sm uppercase tracking-wider flex items-center gap-1.5">
                  <Key className="w-4 h-4 text-slate-500" />
                  Pasos para guardar y configurar tu clave:
                </h4>
                <ol className="space-y-3 pl-4 list-decimal text-sm text-slate-600">
                  <li>
                    Consigue una clave API de Gemini gratis en{" "}
                    <a 
                      href="https://aistudio.google.com/" 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-indigo-600 hover:underline inline-flex items-center gap-1 font-semibold"
                    >
                      Google AI Studio <ExternalLink className="w-3.5 h-3.5" />
                    </a>.
                  </li>
                  <li>
                    Abre la pestaña de **Settings** (Configuración) / botón de engranaje, y ve al panel lateral de **Secrets** (Secretos) en la interfaz de AI Studio.
                  </li>
                  <li>
                    Añade un nuevo secreto llamado exactamente <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-slate-800 font-semibold border border-slate-200">GEMINI_API_KEY</code> y pega tu clave de API allí.
                  </li>
                  <li>
                    Guarda los cambios. El sistema la mantendrá segura y la inyectará automáticamente en cada reinicio o recarga de la app.
                  </li>
                </ol>

                <div className="mt-6 flex gap-3">
                  <button
                    onClick={async () => {
                      try {
                        const res = await fetch("/api/check-env");
                        if (res.ok) {
                          const data = await res.json();
                          setIsKeyMissing(!data.gemini_key_present);
                          if (data.gemini_key_present) {
                            alert("🎉 ¡Conexión Exitosa! La clave API de Gemini ha sido detectada correctamente. Ya puedes usar el tutor de voz.");
                            setShowKeyInstructions(false);
                          } else {
                            alert("❌ Clave no detectada. Recuerda guardarla como GEMINI_API_KEY en Settings > Secrets en AI Studio.");
                          }
                        }
                      } catch (err) {
                        alert("Error al verificar. Intenta recargar la página.");
                      }
                    }}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2.5 rounded-xl text-sm transition-all flex items-center gap-2 shadow-sm"
                  >
                    <Check className="w-4 h-4" />
                    Verificar Conexión Ahora
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        )}

      <AnimatePresence mode="wait">
          {viewMode === 'setup' && (
            <motion.div
              key="setup"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 xl:grid-cols-3 border-b border-white/5"
            >
              {/* Column 1: Tu Cuaderno de Estudio */}
              <div className="p-8 xl:p-10 border-b xl:border-b-0 xl:border-r border-white/5 flex flex-col justify-between gap-8 bg-panel-systematic/20">
                <div>
                  <span className="font-mono text-[10px] text-accent-systematic uppercase tracking-widest block mb-1">Sección / 01</span>
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <h2 className="text-xl font-bold text-ink">Tu Cuaderno de Estudio</h2>
                    {(activeStudyId !== null || files.length > 0 || activeStudyTitle.trim() !== '') && (
                      <button
                        onClick={handleCreateNewNotebook}
                        className="font-mono text-[8px] bg-accent-systematic/10 border border-accent-systematic/25 px-2.5 py-1 text-accent-systematic hover:bg-accent-systematic hover:text-black uppercase tracking-wider font-bold transition-all cursor-pointer rounded"
                        title="Crear un cuaderno desde cero"
                      >
                        ✨ Nuevo Cuaderno
                      </button>
                    )}
                  </div>
                  <p className="text-xs text-ink-muted leading-relaxed mb-6">
                    Primero, asígnale un nombre a tu cuaderno de estudio. Luego, sube tus apuntes o documentos de referencia para que el tutor inteligente los analice.
                  </p>

                  {/* Paso 1: Nombre del Cuaderno */}
                  <div className="mb-6 p-4 bg-zinc-950/40 border border-white/10 rounded-xl space-y-2">
                    <label className="block font-mono text-[9px] text-accent-systematic uppercase tracking-wider font-bold">
                      ✍️ Paso 1: Nombre del Cuaderno
                    </label>
                    <input
                      type="text"
                      placeholder="Ej. Física Avanzada, Historia Americana..."
                      value={activeStudyTitle}
                      onChange={(e) => setActiveStudyTitle(e.target.value)}
                      className="w-full bg-bg-systematic border border-white/15 p-2.5 rounded text-xs text-white placeholder:text-ink-muted focus:border-accent-systematic focus:outline-none transition-all"
                    />
                  </div>

                  {/* Paso 2: Subida de Documentos */}
                  <div className="space-y-2">
                    <label className="block font-mono text-[9px] text-accent-systematic uppercase tracking-wider font-bold">
                      📁 Paso 2: Subir los Archivos
                    </label>

                    {userTier === 'free' && !activeStudyId && userHistory.length >= 2 ? (
                      <div 
                        onClick={() => setShowBillingModal(true)}
                        className="w-full border-2 border-dashed border-red-500/30 p-8 bg-red-950/10 text-center rounded-xl cursor-pointer hover:border-red-500/50 transition-all group"
                      >
                        <span className="text-lg block mb-1.5">🔒</span>
                        <div className="font-mono text-[10px] text-red-400 uppercase tracking-widest font-bold mb-2">
                          Límite de Cuadernos Alcanzado
                        </div>
                        <p className="text-[10px] text-ink-muted leading-relaxed font-mono">
                          Has alcanzado el límite de 2 cuadernos de estudio en tu cuenta gratuita. <span className="text-accent-systematic underline group-hover:text-accent-systematic/80 font-bold">Haz clic aquí para actualizar a PRO</span> y disfrutar de cuadernos ilimitados.
                        </p>
                      </div>
                    ) : activeStudyTitle.trim() === '' ? (
                      <div className="w-full border-2 border-dashed border-white/10 p-8 bg-black/10 text-center rounded-xl">
                        <span className="text-lg block mb-1.5">✍️</span>
                        <p className="text-[10px] text-ink-muted leading-relaxed font-mono">
                          Escribe el nombre de tu cuaderno arriba para habilitar la subida de archivos.
                        </p>
                      </div>
                    ) : (
                      <div
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={handleFileDrop}
                        className="w-full border-2 border-ink p-8 bg-bg-systematic shadow-[6px_6px_0px_#161616] hover:shadow-[8px_8px_0px_#ff4d00] hover:border-accent-systematic transition-all duration-300 cursor-pointer group relative overflow-hidden"
                        onClick={() => document.getElementById('file-upload')?.click()}
                      >
                        <input
                          id="file-upload"
                          type="file"
                          multiple
                          accept="application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword,text/plain,text/markdown,.md,.txt,.csv,.docx,.doc"
                          className="hidden"
                          onChange={handleFileInput}
                        />
                        <div className="font-mono text-[10px] text-accent-systematic uppercase tracking-widest font-bold mb-2">
                          + Subir Fuentes
                        </div>
                        <p className="text-[10px] text-ink-muted leading-relaxed font-mono">
                          Haz clic para explorar o arrastra tus archivos aquí para "{activeStudyTitle}".
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {files.length > 0 && (
                  <div className="mt-8">
                    <span className="font-mono text-[10px] text-accent-systematic uppercase tracking-widest block mb-1">
                      Biblioteca / {files.length} Archivo(s) ({activeFileNames.length} Activo(s))
                    </span>
                    <span className="text-[10px] text-ink-muted leading-relaxed font-mono block mb-3">
                      💡 Selecciona qué fuentes usarás para este estudio:
                    </span>
                    <div className="space-y-2">
                      {files.map((f, i) => {
                        const ext = f.name.split('.').pop()?.toUpperCase() || 'TXT';
                        const isActive = activeFileNames.includes(f.name);
                        return (
                          <div 
                            key={i} 
                            onClick={() => toggleFileActive(f.name)}
                            className={cn(
                              "bg-bg-systematic border p-3.5 flex items-center justify-between text-xs transition-all duration-200 cursor-pointer select-none group rounded-lg",
                              isActive 
                                ? "border-accent-systematic/50 bg-accent-systematic/5 hover:border-accent-systematic" 
                                : "border-white/5 hover:border-white/15 opacity-60 hover:opacity-90"
                            )}
                          >
                            <div className="flex items-center gap-3 max-w-[70%]">
                              <div className="relative flex items-center justify-center shrink-0">
                                <input
                                  type="checkbox"
                                  checked={isActive}
                                  onChange={() => {}} // Handled by parent onClick
                                  className="accent-accent-systematic rounded w-3.5 h-3.5 cursor-pointer"
                                />
                              </div>
                              <span className={cn(
                                "overflow-hidden text-ellipsis whitespace-nowrap font-medium transition-colors truncate",
                                isActive ? "text-white font-semibold" : "text-ink-muted"
                              )}>
                                {f.name}
                              </span>
                            </div>
                            
                            <div className="flex items-center gap-3 shrink-0">
                              <span className={cn(
                                "font-mono text-[8px] uppercase tracking-wider font-bold shrink-0 px-1.5 py-0.5 rounded",
                                isActive 
                                  ? "bg-accent-systematic/15 text-accent-systematic border border-accent-systematic/20" 
                                  : "bg-zinc-800 text-ink-muted border border-zinc-700"
                              )}>
                                {isActive ? "Activo" : "Inactivo"}
                              </span>
                              <span className="font-mono text-[9px] text-ink-muted uppercase tracking-wider">
                                {ext}
                              </span>
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removeFile(i);
                                }}
                                className="p-1 text-ink-muted hover:text-red-400 hover:scale-110 transition-all shrink-0 cursor-pointer bg-transparent border-none"
                                title="Eliminar fuente"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Column 2: Listo para Analizar y/o Historial de Estudios */}
              <div className="bg-panel-systematic/40 p-8 xl:p-10 border-b xl:border-b-0 xl:border-r border-white/5 flex flex-col min-h-[400px] xl:min-h-0">
                {files.length > 0 ? (
                  /* Active Cuaderno Preview */
                  <div className="flex flex-col items-center justify-center text-center max-w-[280px] mx-auto pb-6 border-b border-white/5 mb-6 shrink-0 w-full">
                    <div className="w-[1.5px] h-12 bg-accent-systematic mb-4" />
                    <h3 className="font-display italic text-2xl text-ink mb-1 leading-tight uppercase">Listo para Analizar</h3>
                    <p className="text-ink-muted text-[11px] leading-relaxed mb-4">
                      {isExtracting 
                        ? "Procesando tus documentos para estructurar el temario..."
                        : "El sistema está preparado para analizar tus documentos. Selecciona una metodología de aprendizaje a la derecha."
                      }
                    </p>
                    <div className="font-mono text-[9px] text-accent-systematic uppercase tracking-widest font-bold">
                      {isExtracting 
                        ? "Extrayendo contenido..." 
                        : "Esperando selección..."
                      }
                    </div>
                  </div>
                ) : null}

                {/* Historial Panel */}
                <div className="flex-grow flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="font-mono text-[9px] text-emerald-400 uppercase tracking-widest block font-bold">Historial</span>
                      <h3 className="text-xs font-bold text-ink uppercase tracking-wider">Mis Cuadernos Guardados</h3>
                    </div>
                    {userEmail && (
                      <button
                        onClick={() => fetchUserHistory(userEmail)}
                        className="p-1 text-ink-muted hover:text-emerald-400 transition-colors cursor-pointer text-[10px] font-mono bg-transparent border-none"
                        title="Sincronizar"
                      >
                        🔄 Sincronizar
                      </button>
                    )}
                  </div>

                  {!userEmail ? (
                    <div className="flex-grow flex flex-col items-center justify-center text-center p-4 border border-dashed border-white/5 bg-black/10 rounded-xl">
                      <span className="text-xl mb-2">☁️</span>
                      <h4 className="text-xs font-bold text-white uppercase mb-1">¿Deseas guardar tu historial?</h4>
                      <p className="text-[10px] text-ink-muted leading-relaxed max-w-[200px] mb-3">
                        Identifícate con tu mail o Google para registrar tus sesiones, cargar cuadernos antiguos y seguir estudiando en cualquier lugar.
                      </p>
                      <button
                        onClick={() => {
                          setTempEmailInput('');
                          setTempNameInput('');
                          setShowAuthModal(true);
                        }}
                        className="py-1.5 px-3 bg-emerald-500 hover:bg-emerald-400 text-black font-mono font-bold text-[9px] uppercase tracking-wider rounded cursor-pointer"
                      >
                        Identificarme
                      </button>
                    </div>
                  ) : isLoadingHistory ? (
                    <div className="flex-grow flex flex-col items-center justify-center text-center py-10">
                      <div className="w-5 h-5 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin mb-2" />
                      <span className="font-mono text-[9px] text-ink-muted uppercase">Buscando en la nube...</span>
                    </div>
                  ) : userHistory.length === 0 ? (
                    <div className="flex-grow flex flex-col items-center justify-center text-center p-6 border border-dashed border-white/5 bg-black/10 rounded-xl">
                      <span className="text-xl mb-2">📖</span>
                      <h4 className="text-xs font-bold text-white uppercase mb-1">Aún no hay cuadernos</h4>
                      <p className="text-[10px] text-ink-muted leading-relaxed max-w-[200px]">
                        Sube algunos documentos y haz clic en <strong>"Guardar en Historial"</strong> en la barra lateral para registrar tu primer cuaderno.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
                      {userHistory.map((study) => (
                        <div
                          key={study.id}
                          onClick={() => loadStudy(study)}
                          className={cn(
                            "p-3 rounded-lg border text-left cursor-pointer transition-all flex items-center justify-between group",
                            activeStudyId === study.id
                              ? "bg-emerald-500/5 border-emerald-500/40"
                              : "bg-zinc-950/20 border-white/5 hover:border-white/15"
                          )}
                        >
                          <div className="overflow-hidden mr-3">
                            <h4 className="text-[11px] font-bold text-white uppercase tracking-tight truncate group-hover:text-emerald-400 transition-colors">
                              {study.title}
                            </h4>
                            <p className="text-[9px] text-ink-muted mt-0.5 font-mono truncate">
                              {study.files?.length || 0} doc(s) • {new Date(study.createdAt).toLocaleDateString('es-AR')}
                            </p>
                          </div>
                          
                          <div className="flex items-center gap-1.5 shrink-0">
                            {activeStudyId === study.id && (
                              <span className="text-[8px] font-mono bg-emerald-500/20 text-emerald-400 px-1 rounded uppercase tracking-wider font-bold">
                                Activo
                              </span>
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteStudyFromHistory(study.id, study.title);
                              }}
                              className="p-1 text-ink-muted hover:text-red-400 transition-colors cursor-pointer bg-transparent border-none"
                              title="Eliminar de historial"
                            >
                              ✕
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Column 3: Estudio Inteligente */}
              <div className="p-8 xl:p-10 flex flex-col gap-6 bg-panel-systematic/20">
                <div>
                  <span className="font-mono text-[10px] text-accent-systematic uppercase tracking-widest block mb-1">Sección / 02</span>
                  <h2 className="text-xl font-bold text-ink mb-2">Estudio Inteligente</h2>
                  <p className="text-xs text-ink-muted leading-relaxed mb-4">
                    {files.length === 0 
                      ? "Añade al menos una fuente al cuaderno para activar las herramientas de IA." 
                      : activeFileNames.length === 0
                        ? "Selecciona al menos una fuente activa en tu Biblioteca (marcando su casilla de verificación) para activar las herramientas de IA."
                        : `Tienes ${files.length} documento(s) subido(s) (${activeFileNames.length} activo(s) para estudiar). Selecciona un método de aprendizaje para comenzar:`}
                  </p>

                  <div className="mt-6 flex flex-col">
                    {/* Method 1: Tutoría Libre */}
                    <button
                      disabled={files.length === 0 || activeFileNames.length === 0 || isExtracting}
                      onClick={() => setViewMode('free_session')}
                      className="w-full text-left py-6 border-t border-white/5 hover:border-white/20 disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-300 group text-ink bg-transparent cursor-pointer"
                    >
                      <span className="font-mono text-[9px] text-accent-systematic uppercase tracking-widest block mb-1">01. Asistente de Voz</span>
                      <span className="font-display font-bold text-lg text-ink group-hover:text-accent-systematic group-hover:underline transition-all block mb-1 uppercase">
                        Tutoría Libre (Voz)
                      </span>
                      <p className="text-ink-muted text-xs leading-relaxed">
                        Conversa de forma libre con el tutor sobre el contenido de tus notas.
                      </p>
                    </button>

                    {/* Method 2: Test de Opción Múltiple */}
                    <button
                      disabled={files.length === 0 || activeFileNames.length === 0 || isExtracting}
                      onClick={() => setViewMode('multiple_choice')}
                      className="w-full text-left py-6 border-t border-white/5 hover:border-white/20 disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-300 group text-ink bg-transparent cursor-pointer"
                    >
                      <span className="font-mono text-[9px] text-accent-systematic uppercase tracking-widest block mb-1">02. Cuestionario Escrito</span>
                      <span className="font-display font-bold text-lg text-ink group-hover:text-accent-systematic group-hover:underline transition-all block mb-1 uppercase">
                        Test de Opción Múltiple
                      </span>
                      <p className="text-ink-muted text-xs leading-relaxed">
                        Responde un cuestionario dinámico generado para comprobar tu retención.
                      </p>
                    </button>

                    {/* Method 3: Cuestionario por Voz (Fichas) */}
                    <button
                      disabled={files.length === 0 || activeFileNames.length === 0 || isExtracting || isGeneratingTopics}
                      onClick={generateTopics}
                      className="w-full text-left py-6 border-t border-b border-white/5 hover:border-white/20 disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-300 group text-ink bg-transparent cursor-pointer"
                    >
                      <span className="font-mono text-[9px] text-accent-systematic uppercase tracking-widest block mb-1">03. Tarjetas Interactivas</span>
                      <span className="font-display font-bold text-lg text-ink group-hover:text-accent-systematic group-hover:underline transition-all block mb-1 uppercase">
                        {isExtracting ? "Procesando notas..." : isGeneratingTopics ? "Analizando..." : "Cuestionario por Voz (Fichas)"}
                      </span>
                      <p className="text-ink-muted text-xs leading-relaxed">
                        Desbloquea tarjetas conceptuales ilustradas respondiendo preguntas oralmente.
                      </p>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {viewMode === 'visual' && (
            <motion.div
              key="visual"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="flex flex-col gap-8 max-w-5xl mx-auto p-6"
            >
              <div className="text-center max-w-2xl mx-auto mb-4">
                <span className="font-mono text-[10px] text-accent-systematic uppercase tracking-widest block mb-2">
                  Mapa / Tarjetas Interactivas
                </span>
                <h2 className="text-3xl font-extrabold font-display uppercase tracking-tight text-ink mt-2 mb-4">
                  Temarios Clave Encontrados
                </h2>
                <p className="text-ink-muted text-xs leading-relaxed max-w-lg mx-auto">
                  Estos son los temas principales estructurados por nuestro tutor IA a partir de tu cuaderno. Familiarízate con ellos. Al comenzar el cuestionario por voz, las fichas se bloquearán y deberás desbloquearlas respondiendo correctamente.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {topics.map((topic, idx) => (
                  <div 
                    key={topic.id} 
                    className="bg-panel-systematic border border-white/5 overflow-hidden hover:border-accent-systematic hover:-translate-y-1 transition-all duration-300 flex flex-col group animate-in fade-in slide-in-from-bottom-4 duration-500 shadow-[6px_6px_0px_#161616]"
                    style={{ animationDelay: `${idx * 100}ms` }}
                  >
                    <div className="h-44 overflow-hidden bg-bg-systematic relative border-b border-white/5">
                      <img 
                        src={topic.imageUrl} 
                        alt={topic.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="p-6 flex-grow flex flex-col justify-between">
                      <div>
                        <h3 className="text-base font-bold font-display text-ink mb-2 leading-snug group-hover:text-accent-systematic transition-colors uppercase">
                          {topic.title}
                        </h3>
                        <p className="text-ink-muted text-xs leading-relaxed line-clamp-4">
                          {topic.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-center mt-10">
                <button
                  onClick={startQuiz}
                  className="bg-accent-systematic hover:bg-white text-black font-mono text-xs uppercase tracking-widest py-4 px-10 border border-none transition-all duration-200 active:scale-[0.98] flex items-center gap-3 cursor-pointer font-bold"
                >
                  <Mic className="w-4 h-4 text-black" />
                  Iniciar Cuestionario por Voz
                </button>
              </div>
            </motion.div>
          )}

          {viewMode === 'session' && (
            <motion.div
              key="session"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              <StudySession 
                text={studyText} 
                topics={topics}
                unlockedTopics={unlockedTopics}
                onUnlockTopic={handleUnlockTopic}
                onEnd={() => setViewMode('visual')} 
              />
            </motion.div>
          )}

          {viewMode === 'free_session' && (
            <motion.div
              key="free_session"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              <FreeStudySession 
                text={studyText} 
                onEnd={() => setViewMode('setup')} 
              />
            </motion.div>
          )}

          {viewMode === 'multiple_choice' && (
            <motion.div
              key="multiple_choice"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              <MultipleChoiceQuiz 
                key={`quiz_${activeStudyId || 'new'}_${quizVersion}`}
                text={studyText} 
                onEnd={() => setViewMode('setup')} 
                savedQuestions={savedQuizQuestions}
                onSaveQuestions={(qs) => {
                  setSavedQuizQuestions(qs);
                  if (activeStudyId) {
                    saveCurrentStudy(activeStudyTitle, true, { savedQuizQuestions: qs });
                  }
                }}
                onRegenerate={() => {
                  setSavedQuizQuestions([]);
                  setQuizVersion(v => v + 1);
                  if (activeStudyId) {
                    saveCurrentStudy(activeStudyTitle, true, { savedQuizQuestions: [] });
                  }
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>
        </main>

        {/* Right Inspector Panel (hidden on mobile) */}
        <aside className="hidden lg:flex w-72 flex-col bg-panel-systematic p-8 border-l border-white/5 shrink-0 select-none overflow-y-auto">
          <span className="font-mono text-[9px] text-ink-muted uppercase tracking-widest block mb-4">Registro Activo</span>
          
          {files.length === 0 ? (
            <div className="border border-white/5 p-4 text-center text-ink-muted text-[10px] font-mono uppercase tracking-wider rounded">
              SIN_ARCHIVOS_CARGADOS
            </div>
          ) : (
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {files.map((f, i) => {
                const ext = f.name.split('.').pop()?.toUpperCase() || 'TXT';
                const isActive = activeFileNames.includes(f.name);
                return (
                  <div 
                    key={i} 
                    onClick={() => toggleFileActive(f.name)}
                    className={cn(
                      "font-mono text-[10px] p-2.5 border rounded-lg flex items-center justify-between uppercase transition-all cursor-pointer select-none",
                      isActive 
                        ? "border-accent-systematic/30 bg-accent-systematic/5 text-white" 
                        : "border-white/5 bg-bg-systematic/40 text-ink-muted opacity-60 hover:opacity-90"
                    )}
                  >
                    <div className="flex items-center gap-1.5 truncate max-w-[140px]">
                      <input
                        type="checkbox"
                        checked={isActive}
                        onChange={() => {}} // handled by onClick
                        className="accent-accent-systematic rounded w-3 h-3 cursor-pointer shrink-0"
                      />
                      <span className="truncate font-medium" title={f.name}>{f.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className={cn(
                        "text-[7px] font-bold px-1 rounded shrink-0",
                        isActive ? "bg-accent-systematic/20 text-accent-systematic" : "bg-zinc-800 text-zinc-500"
                      )}>
                        {isActive ? "ON" : "OFF"}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          removeFile(i);
                        }}
                        className="text-red-400 hover:text-red-300 hover:underline shrink-0 cursor-pointer text-[8px] font-bold bg-transparent border-none p-0"
                      >
                        BORRAR
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div className="mt-10">
            <span className="font-mono text-[9px] text-ink-muted uppercase tracking-widest block mb-3">Metadatos del Sistema</span>
            <div className="font-mono text-[10px] text-ink-muted leading-relaxed uppercase space-y-1">
              <div>REF_ID: 4882-TC-VOX</div>
              <div>RED: NODO_001_SA</div>
              <div>LATENCIA: {isExtracting ? 'CALCULANDO...' : '0.2ms'}</div>
              <div>ARCHIVOS: {files.length}</div>
              <div>ESTADO: {isExtracting ? 'PROCESANDO' : 'SISTEMA_PREPARADO'}</div>
            </div>
          </div>

          <button
            onClick={() => setShowKeyInstructions(!showKeyInstructions)}
            className="w-full bg-accent-systematic text-black border-none py-4 px-6 font-mono font-bold text-[10px] uppercase tracking-wider mt-auto cursor-pointer hover:bg-white hover:text-black transition-colors"
          >
            Clave API Terminal
          </button>
        </aside>
      </div>

      {/* MODAL DE MONETIZACIÓN Y PAGOS */}
      <AnimatePresence>
        {showBillingModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowBillingModal(false)}
              className="absolute inset-0 bg-black/85 backdrop-blur-md"
            />

            {/* Modal Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-2xl bg-panel-systematic border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] z-10"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-ink flex items-center gap-2">
                    <Coins className="w-5 h-5 text-accent-systematic" />
                    Monetización & Suscripción Premium
                  </h3>
                  <p className="text-ink-muted text-xs mt-1">
                    Explora el modelo de negocio, la pasarela de pago simulada y el código de Stripe.
                  </p>
                </div>
                <button
                  onClick={() => setShowBillingModal(false)}
                  className="text-ink-muted hover:text-white font-mono text-xs cursor-pointer px-2.5 py-1 border border-white/5 hover:border-white/20 uppercase"
                >
                  Cerrar
                </button>
              </div>

              {/* Sub-Header Tabs */}
              <div className="bg-bg-systematic/50 border-b border-white/5 px-6 py-2 flex gap-2">
                <button
                  onClick={() => setBillingTab('plans')}
                  className={cn(
                    "px-4 py-2 font-mono text-[10px] uppercase tracking-wider font-bold transition-all border-b-2 cursor-pointer",
                    billingTab === 'plans' 
                      ? "border-accent-systematic text-accent-systematic" 
                      : "border-transparent text-ink-muted hover:text-white"
                  )}
                >
                  [01] Planes Premium (Demo Cliente)
                </button>
                <button
                  onClick={() => setBillingTab('monetize')}
                  className={cn(
                    "px-4 py-2 font-mono text-[10px] uppercase tracking-wider font-bold transition-all border-b-2 cursor-pointer",
                    billingTab === 'monetize' 
                      ? "border-accent-systematic text-accent-systematic" 
                      : "border-transparent text-ink-muted hover:text-white"
                  )}
                >
                  [02] Guía de Negocio e Integración
                </button>
              </div>

              {/* Content Panel (Scrollable) */}
              <div className="p-6 md:p-8 overflow-y-auto flex-grow bg-bg-systematic/20">
                {billingTab === 'plans' ? (
                  <div>
                    {paymentStep === 'select' && (
                      <div className="space-y-6">
                        <div className="text-center max-w-md mx-auto mb-2">
                          <span className="font-mono text-[9px] text-accent-systematic uppercase tracking-widest">Pricing Matrix</span>
                          <h4 className="text-xl font-bold uppercase tracking-tight text-white mt-1">Elige un plan de estudio</h4>
                          <p className="text-xs text-ink-muted leading-relaxed mt-1">
                            Comienza gratis con lo básico o desbloquea todo el potencial con nuestro plan para estudiantes profesionales.
                          </p>
                        </div>

                        <div className="grid md:grid-cols-2 gap-6 pt-2">
                          {/* Free Plan Card */}
                          <div className={cn(
                            "border p-6 rounded-xl flex flex-col justify-between relative bg-bg-systematic/30",
                            userTier === 'free' ? "border-accent-systematic bg-accent-systematic/[0.02]" : "border-white/5"
                          )}>
                            {userTier === 'free' && (
                              <span className="absolute -top-2.5 left-6 bg-accent-systematic text-black font-mono text-[8px] font-bold px-2 py-0.5 uppercase tracking-widest rounded">
                                Plan Activo
                              </span>
                            )}
                            <div>
                              <span className="font-mono text-[9px] text-ink-muted uppercase tracking-widest">Plan de Entrada</span>
                              <h5 className="text-lg font-bold uppercase tracking-tight mt-1">Tutor Gratis</h5>
                              <div className="mt-4 mb-5 flex items-baseline gap-1">
                                <span className="text-2xl font-black text-white">$0.00</span>
                                <span className="text-[10px] text-ink-muted uppercase font-mono">/ para siempre</span>
                              </div>
                              <ul className="space-y-2.5 text-xs text-ink-muted">
                                <li className="flex items-start gap-2">
                                  <Check className="w-3.5 h-3.5 text-accent-systematic shrink-0 mt-0.5" />
                                  <span>Hasta 2 documentos simultáneos</span>
                                </li>
                                <li className="flex items-start gap-2">
                                  <Check className="w-3.5 h-3.5 text-accent-systematic shrink-0 mt-0.5" />
                                  <span>Tutoría de voz en tiempo real</span>
                                </li>
                                <li className="flex items-start gap-2">
                                  <Check className="w-3.5 h-3.5 text-accent-systematic shrink-0 mt-0.5" />
                                  <span>Cuestionarios y tarjetas</span>
                                </li>
                              </ul>
                            </div>
                            <div className="mt-8">
                              <button
                                disabled
                                className="w-full py-2.5 border border-white/10 text-[9px] font-mono font-bold uppercase tracking-wider text-ink-muted text-center rounded-lg bg-white/5 cursor-not-allowed"
                              >
                                {userTier === 'free' ? "Plan Actual Activado" : "Plan Gratuito"}
                              </button>
                            </div>
                          </div>

                          {/* PRO Plan Card */}
                          <div className={cn(
                            "border p-6 rounded-xl flex flex-col justify-between relative bg-bg-systematic/30 overflow-hidden",
                            userTier === 'pro' ? "border-amber-500 bg-amber-500/[0.02]" : "border-white/10 hover:border-white/20"
                          )}>
                            <div className="absolute top-0 right-0 bg-amber-500/10 text-amber-400 text-[8px] font-mono font-bold uppercase tracking-widest px-2.5 py-1 border-b border-l border-white/5 rounded-bl-xl">
                              ★ RECOMENDADO
                            </div>
                            {userTier === 'pro' && (
                              <span className="absolute -top-2.5 left-6 bg-amber-500 text-black font-mono text-[8px] font-bold px-2 py-0.5 uppercase tracking-widest rounded">
                                Plan Activo
                              </span>
                            )}
                            <div>
                              <span className="font-mono text-[9px] text-amber-500 uppercase tracking-widest font-bold">Plan Profesional</span>
                              <h5 className="text-lg font-bold uppercase tracking-tight mt-1 text-white">
                                {userDisplayName ? `${userDisplayName} Pro` : 'Estudiante PRO'}
                              </h5>
                              <div className="mt-4 mb-5 flex items-baseline gap-1">
                                <span className="text-2xl font-black text-amber-400">$2.99 USD</span>
                                <span className="text-[10px] text-ink-muted uppercase font-mono">/ al mes</span>
                              </div>
                              <ul className="space-y-2.5 text-xs text-white">
                                <li className="flex items-start gap-2">
                                  <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                                  <span className="font-bold text-amber-200">Documentos ilimitados</span>
                                </li>
                                <li className="flex items-start gap-2">
                                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                                  <span>Tutoría de voz con latencia prioritaria</span>
                                </li>
                                <li className="flex items-start gap-2">
                                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                                  <span>Subidas de PDFs gigantes sin restricciones</span>
                                </li>
                                <li className="flex items-start gap-2">
                                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                                  <span>Insignia dorada ★ PRO en tu pantalla</span>
                                </li>
                              </ul>
                            </div>
                            <div className="mt-8">
                              {userTier === 'pro' ? (
                                <button
                                  disabled
                                  className="w-full py-2.5 bg-amber-500/15 border border-amber-500/30 text-[9px] font-mono font-bold uppercase tracking-wider text-amber-400 text-center rounded-lg cursor-not-allowed"
                                >
                                  Tu cuenta es PRO ✓
                                </button>
                              ) : (
                                <button
                                  onClick={() => setPaymentStep('pay')}
                                  className="w-full py-2.5 bg-accent-systematic text-black hover:bg-white text-[9px] font-mono font-bold uppercase tracking-wider text-center rounded-lg transition-all cursor-pointer"
                                >
                                  Mejorar a PRO ahora
                                </button>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Buy me a coffee card */}
                        <div className="mt-6 border border-white/5 bg-zinc-950/40 rounded-xl p-5 relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-4">
                          <div className="absolute top-0 right-0 bg-accent-systematic/5 w-24 h-24 rounded-full blur-2xl pointer-events-none" />
                          <div className="flex items-center gap-4 text-left">
                            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 text-lg shrink-0">
                              💳
                            </div>
                            <div>
                              <span className="font-mono text-[8px] text-emerald-400 uppercase tracking-widest block mb-0.5">Donación Voluntaria</span>
                              <h5 className="text-xs font-bold text-ink uppercase tracking-tight">¿Prefieres apoyar por Mercado Pago?</h5>
                              <p className="text-[10px] text-ink-muted leading-relaxed max-w-sm">
                                Si te encanta el tutor y prefieres una aportación voluntaria única en vez de suscribirte, puedes colaborar cómodamente con Mercado Pago.
                              </p>
                            </div>
                          </div>
                          <button
                            onClick={() => {
                              setTempCoffeeLink(coffeeLink);
                              setTempCreatorAlias(creatorAlias);
                              setShowCoffeeModal(true);
                            }}
                            className="w-full sm:w-auto px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white font-mono text-[8px] uppercase tracking-widest font-bold rounded-lg border border-white/10 transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                          >
                            <span>Apoyar por Mercado Pago</span>
                            <span>⚡</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {paymentStep === 'pay' && (
                      <div className="space-y-6 max-w-md mx-auto">
                        <button
                          onClick={() => setPaymentStep('select')}
                          className="text-[10px] font-mono text-ink-muted hover:text-white uppercase flex items-center gap-1 bg-transparent border-none cursor-pointer"
                        >
                          ← Volver a los planes
                        </button>

                        <div className="text-center mb-4">
                          <span className="font-mono text-[9px] text-accent-systematic uppercase tracking-widest block">Checkout Seguro</span>
                          <h4 className="text-lg font-bold uppercase tracking-tight text-white">Detalles del Pago</h4>
                          <p className="text-xs text-ink-muted">Completa este simulador interactivo de pago para activar tu cuenta PRO.</p>
                        </div>

                        {/* Interactive Simulated Credit Card */}
                        <div className="w-full bg-gradient-to-br from-neutral-900 to-neutral-950 border border-white/10 rounded-2xl p-5 shadow-lg relative overflow-hidden text-white font-mono select-none">
                          <div className="absolute -right-16 -bottom-16 w-44 h-44 rounded-full bg-accent-systematic/5 blur-3xl pointer-events-none" />
                          <div className="flex justify-between items-start mb-8">
                            <div className="flex flex-col">
                              <span className="text-[8px] text-zinc-500 uppercase tracking-widest">Suscripción Premium</span>
                              <span className="text-xs font-bold text-accent-systematic tracking-wider">TUTOR CUADERNO</span>
                            </div>
                            <div className="w-8 h-5 bg-white/5 border border-white/10 rounded flex items-center justify-center text-[7px] text-zinc-400 font-bold">
                              DEMO
                            </div>
                          </div>

                          {/* Card number representation */}
                          <div className="text-base tracking-widest text-zinc-200 mb-6 font-semibold">
                            {cardNumber ? cardNumber.replace(/(\d{4})/g, '$1 ').trim() : "•••• •••• •••• ••••"}
                          </div>

                          <div className="flex justify-between items-end">
                            <div>
                              <span className="text-[7px] text-zinc-500 block uppercase tracking-wider mb-0.5">Titular</span>
                              <span className="text-[10px] text-zinc-300 uppercase tracking-wider font-semibold truncate max-w-[150px]">
                                {cardName || "JUAN PÉREZ"}
                              </span>
                            </div>
                            <div className="flex gap-4">
                              <div>
                                <span className="text-[7px] text-zinc-500 block uppercase tracking-wider mb-0.5">Expira</span>
                                <span className="text-[10px] text-zinc-300 font-semibold">{cardExpiry || "MM/AA"}</span>
                              </div>
                              <div>
                                <span className="text-[7px] text-zinc-500 block uppercase tracking-wider mb-0.5">CVC</span>
                                <span className="text-[10px] text-zinc-300 font-semibold">{cardCvc || "•••"}</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Payment Inputs */}
                        <form 
                          onSubmit={(e) => {
                            e.preventDefault();
                            if (!cardName || !cardNumber || !cardExpiry || !cardCvc) {
                              alert("Por favor, rellena todos los campos del simulador.");
                              return;
                            }
                            setPaymentStep('processing');
                            setTimeout(() => {
                              handleUpgradeToPro();
                              setPaymentStep('success');
                            }, 2000);
                          }}
                          className="space-y-4"
                        >
                          <div>
                            <label className="block text-[9px] font-mono text-zinc-400 uppercase tracking-wider mb-1.5">Nombre del Titular</label>
                            <input
                              type="text"
                              required
                              placeholder="Ej. Juan Pérez"
                              value={cardName}
                              onChange={(e) => setCardName(e.target.value)}
                              className="w-full bg-zinc-950 border border-white/10 rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none focus:border-accent-systematic transition-colors"
                            />
                          </div>

                          <div>
                            <label className="block text-[9px] font-mono text-zinc-400 uppercase tracking-wider mb-1.5">Número de Tarjeta (Simulado)</label>
                            <input
                              type="text"
                              required
                              maxLength={16}
                              placeholder="4000123456789010"
                              value={cardNumber}
                              onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, ''))}
                              className="w-full bg-zinc-950 border border-white/10 rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none focus:border-accent-systematic transition-colors"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-[9px] font-mono text-zinc-400 uppercase tracking-wider mb-1.5">Vencimiento</label>
                              <input
                                type="text"
                                required
                                maxLength={5}
                                placeholder="MM/AA"
                                value={cardExpiry}
                                onChange={(e) => {
                                  let val = e.target.value;
                                  if (val.length === 2 && !val.includes('/')) {
                                    val = val + '/';
                                  }
                                  setCardExpiry(val);
                                }}
                                className="w-full bg-zinc-950 border border-white/10 rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none focus:border-accent-systematic transition-colors"
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] font-mono text-zinc-400 uppercase tracking-wider mb-1.5">Código de Seguridad (CVC)</label>
                              <input
                                type="text"
                                required
                                maxLength={4}
                                placeholder="123"
                                value={cardCvc}
                                onChange={(e) => setCardCvc(e.target.value.replace(/\D/g, ''))}
                                className="w-full bg-zinc-950 border border-white/10 rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none focus:border-accent-systematic transition-colors"
                              />
                            </div>
                          </div>

                          <div className="bg-emerald-950/20 border border-emerald-900/30 p-3 rounded-lg text-emerald-400 text-[10px] leading-relaxed flex items-start gap-2">
                            <Lock className="w-4 h-4 shrink-0 mt-0.5 text-emerald-500" />
                            <span>
                              <strong>Pasarela Segura de Demostración:</strong> Las claves y tarjetas ingresadas son simuladas localmente y no se realiza ningún cobro real. Es útil para auditar el flujo de usuario.
                            </span>
                          </div>

                          <button
                            type="submit"
                            className="w-full py-3 bg-accent-systematic text-black font-mono font-bold text-[10px] uppercase tracking-wider rounded-lg hover:bg-white transition-all cursor-pointer flex items-center justify-center gap-2"
                          >
                            <CreditCard className="w-4 h-4" />
                            Confirmar Suscripción PRO - $2.99 USD
                          </button>
                        </form>
                      </div>
                    )}

                    {paymentStep === 'processing' && (
                      <div className="py-12 flex flex-col items-center justify-center text-center">
                        <Loader2 className="w-10 h-10 text-accent-systematic animate-spin mb-4" />
                        <h4 className="text-lg font-bold uppercase tracking-tight text-white mb-1">Verificando Transacción</h4>
                        <p className="text-xs text-ink-muted max-w-xs leading-relaxed">
                          La red bancaria simulada está autorizando tu suscripción mensual. Por favor, no cierres esta ventana.
                        </p>
                      </div>
                    )}

                    {paymentStep === 'success' && (
                      <div className="py-10 text-center max-w-sm mx-auto flex flex-col items-center">
                        <div className="w-16 h-16 bg-amber-500/10 text-amber-400 rounded-full flex items-center justify-center border border-amber-500/30 mb-6 animate-bounce">
                          <Sparkles className="w-8 h-8" />
                        </div>
                        <h4 className="text-xl font-bold uppercase tracking-tight text-white mb-2">¡Bienvenido al Plan PRO! ★</h4>
                        <p className="text-xs text-ink-muted leading-relaxed mb-6">
                          Felicidades. Tu cuenta ha sido mejorada al nivel de <strong>Suscripción Profesional</strong>. Ahora cuentas con documentos ilimitados y prioridad de procesamiento por IA.
                        </p>
                        <button
                          onClick={() => setShowBillingModal(false)}
                          className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-black font-mono font-bold text-[10px] uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
                        >
                          Empezar a estudiar en PRO
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-6 text-left">
                    <div className="border-b border-white/5 pb-4 mb-2">
                      <h4 className="text-base font-bold text-white uppercase tracking-tight flex items-center gap-1.5">
                        <Coins className="w-4 h-4 text-accent-systematic" />
                        Guía de Monetización de Tutor Cuaderno
                      </h4>
                      <p className="text-xs text-ink-muted leading-relaxed mt-1">
                        Aprende cómo funciona el modelo de negocio SaaS (Software as a Service) detrás de esta app y cómo puedes obtener ingresos reales con ella.
                      </p>
                    </div>

                    <div className="space-y-5 text-xs text-zinc-300 leading-relaxed">
                      <div>
                        <h5 className="font-bold text-accent-systematic uppercase tracking-wider mb-1.5">1. Rentabilidad Excepcional por IA</h5>
                        <p className="mb-2">
                          Esta app procesa texto y audio con la API de <strong>Gemini 1.5/2.0 Flash</strong>, cuyo costo por uso es casi cero:
                        </p>
                        <div className="bg-zinc-950 p-3 rounded-lg border border-white/5 font-mono text-[10px] space-y-1.5 text-zinc-400">
                          <div>• Costo por 1M tokens de entrada: <span className="text-emerald-400">$0.075 USD</span></div>
                          <div>• Costo por 1M tokens de salida: <span className="text-emerald-400">$0.30 USD</span></div>
                          <div>• Costo promedio de estudiar 1 hora: <span className="text-emerald-400">&lt; $0.01 USD</span></div>
                        </div>
                        <p className="mt-2 text-[11px] text-zinc-400">
                          Si cobras una suscripción mensual de <strong>$2.99 USD</strong>, tu costo por usuario activo será extremadamente bajo (menos de $0.15 USD al mes). ¡Tu margen de ganancia operativa supera el <strong>95%</strong>!
                        </p>
                      </div>

                      <div>
                        <h5 className="font-bold text-accent-systematic uppercase tracking-wider mb-1.5">2. El Modelo Freemium con Límites</h5>
                        <p>
                          La clave para motivar la compra de un producto educativo es ofrecer valor inmediato y establecer un límite de uso. En el archivo de esta aplicación, hemos programado un límite estricto de un máximo de <strong>2 documentos gratuitos</strong>. Cuando un estudiante sube un tercero, la app despliega el paywall de forma orgánica, atrayendo la conversión de inmediato.
                        </p>
                      </div>

                      <div>
                        <h5 className="font-bold text-zinc-100 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                          <CreditCard className="w-4 h-4 text-accent-systematic" />
                          3. Cómo conectar Stripe Real (Backend Code)
                        </h5>
                        <p className="mb-2">
                          Para procesar dinero de verdad, puedes instalar el SDK oficial de Stripe: <code className="bg-zinc-900 text-zinc-200 px-1 py-0.5 rounded font-mono">npm install stripe</code>. En tu backend de Express (<code className="text-zinc-200 font-mono">server.ts</code>), agregarías un endpoint para crear el checkout seguro:
                        </p>
                        <pre className="bg-zinc-950 p-4 rounded-lg border border-white/5 font-mono text-[9px] text-zinc-400 overflow-x-auto select-all leading-normal whitespace-pre-wrap">
{`// server.ts (Backend)
import Stripe from 'stripe';
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

app.post('/api/create-checkout', async (req, res) => {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [{
      price_data: {
        currency: 'usd',
        product_data: { name: 'Suscripción Tutor Cuaderno PRO' },
        unit_amount: 299, // $2.99 USD
        recurring: { interval: 'month' },
      },
      quantity: 1,
    }],
    mode: 'subscription',
    success_url: 'https://tu-dominio.com/?payment=success',
    cancel_url: 'https://tu-dominio.com/?payment=cancel',
  });
  res.json({ url: session.url });
});`}
                        </pre>
                      </div>

                      <div>
                        <h5 className="font-bold text-accent-systematic uppercase tracking-wider mb-1.5">4. Procesamiento Automático de Suscripciones (Webhooks)</h5>
                        <p className="mb-2">
                          Cuando el usuario pague en Stripe, Stripe enviará un webhook a tu servidor para actualizar el estado del usuario en la base de datos de manera automatizada:
                        </p>
                        <pre className="bg-zinc-950 p-4 rounded-lg border border-white/5 font-mono text-[9px] text-zinc-400 overflow-x-auto select-all leading-normal whitespace-pre-wrap">
{`app.post('/api/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature']!;
  const event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;
    const customerEmail = session.customer_details?.email;
    // AQUÍ: Actualizas el tier del usuario a 'pro' en tu Base de Datos (ej. Firestore/Cloud SQL)
    console.log(\`Suscripción PRO activada para: \${customerEmail}\`);
  }
  res.json({ received: true });
});`}
                        </pre>
                      </div>

                      <div className="pt-2">
                        <div className="bg-white/5 p-4 rounded-lg border border-white/5">
                          <h6 className="font-bold text-white mb-1 uppercase text-[10px]">Estrategia de Lanzamiento Recomendada:</h6>
                          <p className="text-[11px] text-zinc-400">
                            Promociona la herramienta en grupos de WhatsApp de facultades, redes sociales como TikTok, o foros de estudiantes. Con un costo de hosting mensual gratuito de Cloud Run y base de datos Firestore, tus costos fijos iniciales serán de $0.00 al mes, permitiéndote rentabilizar desde la primera suscripción vendida.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-6 border-t border-white/5 bg-bg-systematic/50 flex justify-end">
                <button
                  onClick={() => setShowBillingModal(false)}
                  className="px-5 py-2.5 bg-white text-black hover:bg-accent-systematic font-mono text-[10px] uppercase tracking-wider font-bold transition-all cursor-pointer rounded"
                >
                  Regresar a la App
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL DE CAFECITO Y CONFIGURACIÓN DE DONACIÓN */}
      <AnimatePresence>
        {showCoffeeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCoffeeModal(false)}
              className="absolute inset-0 bg-black/85 backdrop-blur-md"
            />

            {/* Modal Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-lg bg-panel-systematic border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">💳</span>
                  <div>
                    <h3 className="text-sm font-bold text-ink uppercase tracking-tight">
                      Apoyar Proyecto / Mercado Pago
                    </h3>
                    <p className="text-ink-muted text-[10px] uppercase font-mono tracking-wider">
                      Donación voluntaria para {creatorAlias}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowCoffeeModal(false)}
                  className="text-ink-muted hover:text-white font-mono text-[10px] cursor-pointer px-2 py-0.5 border border-white/5 hover:border-white/10 uppercase bg-transparent"
                >
                  Cerrar
                </button>
              </div>

              {/* Content Panel */}
              <div className="p-6 overflow-y-auto flex-grow bg-bg-systematic/20 space-y-6">
                <div className="text-center max-w-md mx-auto">
                  <div className="w-12 h-12 bg-emerald-500/10 text-emerald-400 rounded-xl flex items-center justify-center border border-emerald-500/20 mx-auto mb-3 text-xl">
                    🇦🇷
                  </div>
                  <h4 className="text-sm font-bold uppercase tracking-tight text-white">Aporte Voluntario Único</h4>
                  <p className="text-[11px] text-ink-muted leading-relaxed mt-1">
                    Si te sirve el tutor inteligente y deseas apoyarnos, puedes colaborar de forma voluntaria de manera directa y rápida a través de Mercado Pago.
                  </p>
                </div>

                <div className="max-w-sm mx-auto">
                  {/* Mercado Pago Alias Copy card */}
                  <div className="border border-emerald-500/15 bg-zinc-950/40 rounded-xl p-6 flex flex-col items-center justify-between space-y-4 shadow-xl">
                    <div className="text-center space-y-1">
                      <span className="font-mono text-[8px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 uppercase tracking-widest font-bold">Transferencia Directa</span>
                      <h5 className="text-sm font-bold text-white uppercase tracking-wider mt-1">Mercado Pago Argentina</h5>
                    </div>
                    
                    <div className="w-full bg-black/40 p-4 rounded-lg border border-white/5 text-center relative group">
                      <span className="text-[8px] font-mono uppercase tracking-wider text-ink-muted block mb-1">Alias de Destino:</span>
                      <span className="text-sm font-mono text-white block select-all font-black tracking-widest bg-zinc-900/60 py-2 px-3 rounded border border-white/5">{creatorAlias}</span>
                      <span className="text-[9px] font-sans text-ink-muted mt-2 block">
                        Titular de la cuenta: <strong className="text-white font-medium">Cristian Martín Veloz</strong>
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(creatorAlias);
                        alert(`¡Alias "${creatorAlias}" copiado al portapapeles!`);
                      }}
                      className="w-full py-3.5 bg-emerald-500 text-black hover:bg-emerald-400 hover:scale-[1.01] text-center font-mono font-bold text-[10px] uppercase tracking-wider rounded-lg border border-transparent transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-[0_0_15px_rgba(16,185,129,0.2)]"
                    >
                      <span>Copiar Alias</span>
                      <span>📋</span>
                    </button>
                  </div>
                </div>

                {/* Configuration Section for the creator */}
                <div className="border border-amber-500/10 bg-amber-500/5 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="text-amber-500 text-xs">⚙️</span>
                      <span className="font-mono text-[8px] text-amber-500 uppercase tracking-widest font-bold">
                        Configurar Enlace y Alias (Persistente)
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        if (isEditingCoffeeLink) {
                          handleSaveCoffeeLink();
                        } else {
                          setTempCoffeeLink(coffeeLink);
                          setTempCreatorAlias(creatorAlias);
                          setIsEditingCoffeeLink(true);
                        }
                      }}
                      className="font-mono text-[8px] uppercase tracking-wider text-amber-500 hover:text-white underline cursor-pointer bg-transparent border-none"
                    >
                      {isEditingCoffeeLink ? "[Guardar Destino]" : "[Editar Datos]"}
                    </button>
                  </div>

                  {isEditingCoffeeLink ? (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-mono text-ink-muted uppercase block">Link de Pago / URL de Mercado Pago:</label>
                        <input
                          type="text"
                          value={tempCoffeeLink}
                          onChange={(e) => setTempCoffeeLink(e.target.value)}
                          placeholder="https://link.mercadopago.com.ar/..."
                          className="w-full bg-zinc-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-[11px] text-white focus:outline-none focus:border-accent-systematic"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-mono text-ink-muted uppercase block">Alias o CVU de Mercado Pago:</label>
                        <input
                          type="text"
                          value={tempCreatorAlias}
                          onChange={(e) => setTempCreatorAlias(e.target.value)}
                          placeholder="martinmano"
                          className="w-full bg-zinc-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-[11px] text-white focus:outline-none focus:border-accent-systematic"
                        />
                      </div>
                      <div className="flex justify-end">
                        <button
                          onClick={handleSaveCoffeeLink}
                          className="bg-accent-systematic text-black font-mono text-[9px] uppercase tracking-wider px-3 py-1.5 rounded-lg font-bold hover:bg-white cursor-pointer border-none"
                        >
                          Guardar Configuración
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-[10px] space-y-1.5">
                      <div>
                        <span className="text-ink-muted text-[9px] uppercase font-mono block">Enlace actual configurado:</span>
                        <code className="text-emerald-400/90 truncate block bg-black/35 p-2 rounded mt-1 border border-white/5">{coffeeLink}</code>
                      </div>
                      <div>
                        <span className="text-ink-muted text-[9px] uppercase font-mono block">Alias actual configurado:</span>
                        <code className="text-emerald-400/90 truncate block bg-black/35 p-2 rounded mt-1 border border-white/5">{creatorAlias}</code>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-white/5 bg-bg-systematic/50 flex justify-end">
                <button
                  onClick={() => setShowCoffeeModal(false)}
                  className="px-5 py-2 bg-white text-black hover:bg-emerald-400 font-mono text-[9px] uppercase tracking-wider font-bold transition-all cursor-pointer rounded border-none"
                >
                  Regresar a la App
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL DE IDENTIFICACIÓN DE ESTUDIANTE */}
      <AnimatePresence>
        {showAuthModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAuthModal(false)}
              className="absolute inset-0 bg-black/85 backdrop-blur-md"
            />

            {/* Modal Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-md bg-panel-systematic border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col z-10"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">👤</span>
                  <div>
                    <h3 className="text-sm font-bold text-ink uppercase tracking-tight">
                      Identificación del Estudiante
                    </h3>
                    <p className="text-ink-muted text-[10px] uppercase font-mono tracking-wider">
                      Guarda tus apuntes y progresos
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowAuthModal(false)}
                  className="text-ink-muted hover:text-white font-mono text-[10px] cursor-pointer px-2 py-0.5 border border-white/5 hover:border-white/10 uppercase bg-transparent"
                >
                  ✕
                </button>
              </div>

              {/* Content Panel */}
              <div className="p-6 bg-bg-systematic/20 space-y-4">
                <p className="text-xs text-ink-muted leading-relaxed">
                  Para registrar tu historial de estudio de la manera más rápida y sencilla, ingresa tu correo electrónico y tu nombre.
                </p>

                <div className="space-y-3">
                  <div>
                    <label className="block font-mono text-[9px] text-ink-muted uppercase tracking-wider mb-1">Nombre Completo</label>
                    <input
                      type="text"
                      placeholder="Ej. Martín Mano"
                      value={tempNameInput}
                      onChange={(e) => setTempNameInput(e.target.value)}
                      className="w-full bg-bg-systematic border border-white/10 p-3 rounded text-xs text-ink placeholder:text-ink-muted focus:border-accent-systematic focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-mono text-[9px] text-ink-muted uppercase tracking-wider mb-1">Correo Electrónico</label>
                    <input
                      type="email"
                      placeholder="martinvelozz01@gmail.com"
                      value={tempEmailInput}
                      onChange={(e) => setTempEmailInput(e.target.value)}
                      className="w-full bg-bg-systematic border border-white/10 p-3 rounded text-xs text-ink placeholder:text-ink-muted focus:border-accent-systematic focus:outline-none"
                    />
                  </div>
                </div>

                {/* Google Sign-In Quick-Mock button for maximum convenience */}
                <div className="relative flex py-2 items-center">
                  <div className="flex-grow border-t border-white/5"></div>
                  <span className="flex-shrink mx-4 text-[9px] font-mono text-ink-muted uppercase">O continuar con</span>
                  <div className="flex-grow border-t border-white/5"></div>
                </div>

                <button
                  onClick={() => {
                    // Quick Google Mock login with user's email
                    const email = "martinvelozz01@gmail.com";
                    const name = "Martín";
                    handleIdentifyUser(email, name);
                    setShowAuthModal(false);
                  }}
                  className="w-full py-2.5 bg-white text-black hover:bg-zinc-200 transition-colors text-xs font-bold rounded flex items-center justify-center gap-2 cursor-pointer border-none"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22-.03-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                  <span>Continuar con Google</span>
                </button>
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-white/5 bg-bg-systematic/50 flex justify-end gap-2">
                <button
                  onClick={() => setShowAuthModal(false)}
                  className="px-4 py-2 border border-white/10 hover:border-white/20 text-ink font-mono text-[9px] uppercase tracking-wider rounded cursor-pointer bg-transparent"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    if (!tempEmailInput.trim()) {
                      alert('Por favor ingresa tu correo electrónico.');
                      return;
                    }
                    const name = tempNameInput.trim() || tempEmailInput.split('@')[0];
                    handleIdentifyUser(tempEmailInput.trim(), name);
                    setShowAuthModal(false);
                  }}
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-mono text-[9px] uppercase tracking-wider font-bold rounded cursor-pointer border-none"
                >
                  Registrarme
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL DE GUARDADO DE CUADERNO */}
      <AnimatePresence>
        {showSaveStudyModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSaveStudyModal(false)}
              className="absolute inset-0 bg-black/85 backdrop-blur-md"
            />

            {/* Modal Container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-md bg-panel-systematic border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col z-10"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">💾</span>
                  <div>
                    <h3 className="text-sm font-bold text-ink uppercase tracking-tight">
                      {activeStudyId ? "Guardar Cambios del Cuaderno" : "Guardar Nuevo Cuaderno"}
                    </h3>
                    <p className="text-ink-muted text-[10px] uppercase font-mono tracking-wider">
                      Persistencia en tu historial
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowSaveStudyModal(false)}
                  className="text-ink-muted hover:text-white font-mono text-[10px] cursor-pointer px-2 py-0.5 border border-white/5 hover:border-white/10 uppercase bg-transparent"
                >
                  ✕
                </button>
              </div>

              {/* Content Panel */}
              <div className="p-6 bg-bg-systematic/20 space-y-4">
                <p className="text-xs text-ink-muted leading-relaxed">
                  Asigna un título descriptivo a este cuaderno para identificarlo en tu historial y recuperarlo cuando quieras.
                </p>

                <div>
                  <label className="block font-mono text-[9px] text-ink-muted uppercase tracking-wider mb-1">Título del Cuaderno</label>
                  <input
                    type="text"
                    placeholder="Ej. Física Teórica - Examen Final"
                    value={newStudyTitle}
                    onChange={(e) => setNewStudyTitle(e.target.value)}
                    className="w-full bg-bg-systematic border border-white/10 p-3 rounded text-xs text-ink placeholder:text-ink-muted focus:border-accent-systematic focus:outline-none"
                  />
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-white/5 bg-bg-systematic/50 flex justify-end gap-2">
                <button
                  onClick={() => setShowSaveStudyModal(false)}
                  className="px-4 py-2 border border-white/10 hover:border-white/20 text-ink font-mono text-[9px] uppercase tracking-wider rounded cursor-pointer bg-transparent"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    const titleToSave = newStudyTitle.trim() || `Cuaderno ${new Date().toLocaleDateString('es-AR')}`;
                    saveCurrentStudy(titleToSave);
                    setShowSaveStudyModal(false);
                  }}
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-mono text-[9px] uppercase tracking-wider font-bold rounded cursor-pointer border-none"
                >
                  Guardar Cuaderno
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Bottom Bar / Footer */}
      <footer className="h-12 border-t border-white/5 px-8 flex items-center justify-between font-mono text-[9px] uppercase tracking-widest text-ink-muted bg-bg-systematic shrink-0 z-20">
        <div className="flex items-center">
          <span className="inline-block w-1.5 h-1.5 bg-accent-systematic rounded-full mr-2 animate-pulse"></span>
          <span>{isExtracting ? 'SISTEMA_PROCESANDO_DOCUMENTOS' : 'SISTEMA_LISTO_PARA_PROCESAR'}</span>
        </div>
        <div className="hidden sm:block">
          <span>CAPA_DE_VOZ_CONECTADA_V2.0 // (C) 2024 AI TUTOR LABS</span>
        </div>
      </footer>
    </div>
  );
}

function ApiKeyErrorGuide({ onRetry }: { onRetry?: () => void }) {
  const [checking, setChecking] = useState(false);
  
  const handleCheck = async () => {
    setChecking(true);
    try {
      const res = await fetch("/api/check-env");
      if (res.ok) {
        const data = await res.json();
        if (data.gemini_key_present) {
          alert("🎉 ¡Clave API detectada con éxito! La conexión ha sido restablecida. Haz clic en Continuar o reintenta.");
          if (onRetry) onRetry();
        } else {
          alert("❌ Aún no detectamos la clave. Asegúrate de guardarla como GEMINI_API_KEY en 'Settings > Secrets' (Configuración > Secretos) en la esquina de AI Studio.");
        }
      }
    } catch (_) {
      alert("Error de conexión. Intenta recargar la página.");
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 text-left max-w-xl mx-auto shadow-sm mt-4">
      <h4 className="text-slate-900 font-bold mb-3 flex items-center gap-2 text-sm uppercase tracking-wider">
        <Key className="w-5 h-5 text-indigo-500 shrink-0" />
        ¿Cómo solucionar la conexión con el tutor?
      </h4>
      
      <p className="text-slate-600 text-sm mb-4 leading-relaxed">
        El tutor por voz requiere una clave <strong>GEMINI_API_KEY</strong> activa para funcionar. Sigue estos sencillos pasos para guardarla de forma segura y permanente en tu entorno de desarrollo:
      </p>

      <ol className="space-y-2.5 text-xs text-slate-600 list-decimal pl-4 mb-5 leading-relaxed">
        <li>
          Obtén una clave API gratis en{" "}
          <a 
            href="https://aistudio.google.com/" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-indigo-600 hover:underline font-semibold inline-flex items-center gap-1"
          >
            Google AI Studio <ExternalLink className="w-3 h-3" />
          </a>.
        </li>
        <li>
          Abre la pestaña de <strong>Settings</strong> (Configuración - icono de engranaje) en la esquina superior/barra lateral de la interfaz de AI Studio.
        </li>
        <li>
          Ve a la pestaña de <strong>Secrets</strong> (Secretos) y añade un nuevo secreto.
        </li>
        <li>
          Usa exactamente el nombre: <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-slate-800 font-bold border border-slate-200">GEMINI_API_KEY</code> y pega tu clave como valor.
        </li>
        <li>
          Guarda. El sistema la mantendrá segura y protegida de forma permanente.
        </li>
      </ol>

      <div className="border-t border-slate-200 pt-4 mt-4">
        <h5 className="font-bold text-xs text-slate-800 mb-2 flex items-center gap-1">
          <Lock className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
          ¿Y qué pasa cuando comparto o publico la App?
        </h5>
        <p className="text-slate-500 text-xs leading-relaxed mb-4">
          ¡No te preocupes por la seguridad! Tus claves están seguras y nunca se comparten. Cuando otra persona use tu enlace publicado, <strong>Google AI Studio le pedirá de forma segura que ingrese su propia clave de API</strong>. Nadie consumirá tus créditos ni tendrá acceso a tu clave privada.
        </p>
      </div>

      <div className="flex gap-3">
        <button
          onClick={handleCheck}
          disabled={checking}
          className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-semibold px-4 py-2 rounded-xl text-xs transition-all shadow-sm flex items-center gap-1.5"
        >
          {checking ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Check className="w-3.5 h-3.5" />
          )}
          Verificar Conexión Ahora
        </button>
      </div>
    </div>
  );
}

function MicErrorGuide() {
  return (
    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 text-left max-w-xl mx-auto shadow-sm mt-4">
      <h4 className="text-slate-900 font-bold mb-3 flex items-center gap-2 text-sm uppercase tracking-wider">
        <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
        ¿Cómo solucionar el acceso al micrófono?
      </h4>
      
      <p className="text-slate-600 text-sm mb-4 leading-relaxed">
        El tutor requiere acceso al micrófono para escucharte. Debido a que estás visualizando la aplicación dentro de la vista previa de AI Studio (que corre en un marco seguro o <em>iframe</em>), los navegadores web modernos suelen bloquear el micrófono por seguridad.
      </p>

      <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 mb-4">
        <h5 className="font-bold text-xs text-indigo-900 mb-1.5 flex items-center gap-1">
          <ExternalLink className="w-4 h-4 text-indigo-600 shrink-0" />
          ¡Solución instantánea en 1 paso!
        </h5>
        <p className="text-indigo-950 text-xs leading-relaxed">
          Haz clic en el botón de la esquina superior derecha de la pantalla de AI Studio: <strong>"Open in new tab" (Abrir en pestaña nueva)</strong> (o el icono con la flechita hacia afuera <ExternalLink className="inline-block w-3 h-3 ml-0.5" />). Al abrir la app en su propia pestaña, el navegador te solicitará el permiso del micrófono de manera normal.
        </p>
      </div>

      <div className="text-xs text-slate-500 leading-relaxed">
        Una vez que abras la aplicación en una pestaña independiente, vuelve a hacer clic en <strong>"Empezar Cuestionario"</strong> y selecciona <strong>Permitir micrófono</strong> cuando tu navegador te lo solicite.
      </div>
    </div>
  );
}

function StudySession({ 
  text, 
  topics,
  unlockedTopics,
  onUnlockTopic,
  onEnd 
}: { 
  text: string; 
  topics: Topic[];
  unlockedTopics: string[];
  onUnlockTopic: (id: string) => void;
  onEnd: () => void; 
}) {
  const [isConnecting, setIsConnecting] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const sessionRef = useRef<any>(null);
  const playerRef = useRef<AudioStreamPlayer | null>(null);
  const recorderRef = useRef<AudioRecorder | null>(null);

  useEffect(() => {
    let isMounted = true;

    const startSession = async () => {
      try {
        try {
          const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          micStream.getTracks().forEach(track => track.stop());
        } catch (micErr) {
          console.error("Microphone access failed:", micErr);
          if (isMounted) {
            setError("No se pudo acceder al micrófono. Por favor permite el acceso al micrófono en tu navegador e intenta de nuevo.");
            setIsConnecting(false);
          }
          return;
        }

        playerRef.current = new AudioStreamPlayer(24000);
        
        const session = new WebSocketSession({
          mode: 'topics',
          text,
          topics,
        });
        
        const sessionPromise = Promise.resolve(session);

        session.setCallbacks({
          onopen: () => {
            if (!isMounted) return;
            setIsConnecting(false);
            
            recorderRef.current = new AudioRecorder((base64) => {
              sessionPromise.then(session => {
                session.sendRealtimeInput({
                  audio: { data: base64, mimeType: 'audio/pcm;rate=16000' }
                });
              });
            });
            recorderRef.current.start().catch((err: any) => {
              console.error("Error starting recording:", err);
              if (isMounted) {
                setError("No se pudo iniciar el grabador de audio. Por favor verifica los permisos.");
                setIsConnecting(false);
              }
            });
          },
          onmessage: (message: any) => {
            if (!isMounted) return;
            
            if (message.toolCall) {
              const functionCalls = message.toolCall.functionCalls;
              if (functionCalls) {
                const responses: any[] = [];
                for (const call of functionCalls) {
                  if (call.name === 'unlockTopic') {
                    const args = call.args as any;
                    if (args && args.topicId) {
                      onUnlockTopic(args.topicId);
                    }
                    responses.push({
                      id: call.id,
                      name: call.name,
                      response: { result: "Tema desbloqueado en la interfaz exitosamente." }
                    });
                  }
                }
                if (responses.length > 0) {
                  sessionPromise.then(session => {
                    session.sendToolResponse({ functionResponses: responses });
                  });
                }
              }
            }

            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              setIsSpeaking(true);
              playerRef.current?.addPCM16(base64Audio);
            }
            
            if (message.serverContent?.interrupted) {
              playerRef.current?.interrupt();
              setIsSpeaking(false);
            }
            
            if (message.serverContent?.turnComplete) {
              setIsSpeaking(false);
            }
          },
          onclose: () => {
            if (isMounted) {
              onEnd();
            }
          },
          onerror: (err: any) => {
            console.error("Live API Error:", err);
            if (isMounted) {
              setError(err?.message || "Se perdió la conexión con el tutor.");
            }
          }
        });
        
        sessionRef.current = sessionPromise;
      } catch (err) {
        console.error("Failed to start session:", err);
        if (isMounted) {
          setError("No se pudo iniciar la sesión. Verifica tus permisos de micrófono.");
          setIsConnecting(false);
        }
      }
    };

    startSession();

    return () => {
      isMounted = false;
      recorderRef.current?.stop();
      playerRef.current?.stop();
      sessionRef.current?.then((s: any) => s.close());
    };
  }, [text, topics, onUnlockTopic, onEnd]);

  return (
    <div className="flex flex-col lg:flex-row gap-12 items-start justify-center min-h-[70vh] p-6">
      {/* Topics Grid Sidebar */}
      <div className="w-full lg:w-1/2 grid grid-cols-2 gap-4">
        {topics.map((topic, index) => {
          const isUnlocked = unlockedTopics.includes(topic.id);
          const isCurrent = !isUnlocked && topics.findIndex(t => !unlockedTopics.includes(t.id)) === index;
          
          return (
            <div 
              key={topic.id} 
              className={cn(
                "border transition-all duration-500 relative",
                isUnlocked ? "border-white/5 bg-panel-systematic shadow-sm" : 
                isCurrent ? "border-accent-systematic bg-accent-systematic/5 shadow-[4px_4px_0px_#ff4d00] ring-1 ring-accent-systematic/30" : 
                "border-white/5 bg-panel-systematic/20 opacity-40"
              )}
            >
              <div className="h-32 relative overflow-hidden bg-bg-systematic flex items-center justify-center border-b border-white/5">
                {isUnlocked ? (
                  <img 
                    src={topic.imageUrl} 
                    alt={topic.title} 
                    className="w-full h-full object-cover animate-in fade-in duration-1000"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className={cn(
                    "absolute inset-0 flex flex-col items-center justify-center transition-colors",
                    isCurrent ? "bg-bg-systematic text-accent-systematic" : "bg-bg-systematic text-ink-muted"
                  )}>
                    <Lock className={cn("w-5 h-5 mb-2", isCurrent ? "animate-bounce" : "opacity-40")} />
                    <span className="text-[9px] font-mono uppercase tracking-widest font-bold">
                      {isCurrent ? "Pregunta actual" : "Bloqueado"}
                    </span>
                  </div>
                )}
              </div>
              <div className="p-4">
                <h4 className={cn(
                  "font-bold text-xs mb-1 line-clamp-2 leading-snug uppercase",
                  isUnlocked ? "text-ink" : 
                  isCurrent ? "text-ink" : "text-ink-muted"
                )}>
                  {topic.title}
                </h4>
                {isUnlocked && (
                  <span className="inline-flex items-center gap-1 text-[9px] font-mono font-bold text-emerald-400 bg-emerald-950/20 border border-emerald-900/30 px-2 py-0.5 rounded mt-2 uppercase tracking-widest">
                    <Unlock className="w-2.5 h-2.5" />
                    Completado
                  </span>
                )}
                {isCurrent && (
                  <span className="inline-flex items-center gap-1 text-[9px] font-mono font-bold text-accent-systematic bg-accent-systematic/10 border border-accent-systematic px-2 py-0.5 rounded mt-2 uppercase tracking-widest animate-pulse">
                    <Sparkles className="w-2.5 h-2.5" />
                    Responde por voz
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Voice Interaction Center */}
      <div className="w-full lg:w-1/2 flex flex-col items-center justify-center bg-panel-systematic border border-white/5 p-10 shadow-[6px_6px_0px_#161616] sticky top-24">
        {error ? (
          <div className="bg-red-950/20 border border-red-900/30 text-red-400 p-6 rounded-2xl w-full text-center">
            <p className="font-semibold mb-4 text-sm">{error}</p>
            {(error.includes("GEMINI_API_KEY") || error.includes("clave API")) && (
              <div className="mt-4 text-white">
                <ApiKeyErrorGuide />
              </div>
            )}
            {(error.toLowerCase().includes("micrófono") || error.toLowerCase().includes("permis") || error.toLowerCase().includes("denied")) && (
              <div className="mt-4 text-white">
                <MicErrorGuide />
              </div>
            )}
            <button
              onClick={onEnd}
              className="mt-6 bg-red-950/40 hover:bg-red-900/40 text-red-200 border border-red-900/30 px-5 py-2.5 rounded-xl font-bold text-xs transition-colors cursor-pointer"
            >
              Volver al cuaderno
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center w-full">
            <div className="relative w-48 h-48 mb-6 flex items-center justify-center">
              {/* Pulsing background rings */}
              <div className={cn(
                "absolute inset-0 rounded-full bg-accent-systematic/10 transition-all duration-500",
                isConnecting ? "animate-ping" : isSpeaking ? "animate-pulse scale-150 opacity-20" : "scale-110"
              )} />
              <div className={cn(
                "absolute inset-4 rounded-full bg-accent-systematic/15 transition-all duration-300",
                isSpeaking ? "animate-pulse scale-125 opacity-35" : "scale-100"
              )} />
              
              {/* Center orb */}
              <div className={cn(
                "relative z-10 w-24 h-24 rounded-full flex items-center justify-center shadow-lg transition-all duration-500 border border-white/10",
                isConnecting ? "bg-bg-systematic text-ink-muted" : "bg-accent-systematic text-black shadow-[4px_4px_0px_#000000]"
              )}>
                {isConnecting ? (
                  <Loader2 className="w-8 h-8 animate-spin" />
                ) : isSpeaking ? (
                  <Volume2 className="w-8 h-8 text-black animate-bounce" />
                ) : (
                  <Mic className="w-8 h-8 text-black" />
                )}
              </div>
            </div>

            {/* Siri/Gemini wave indicator */}
            {!isConnecting && (
              <div className="flex items-end justify-center gap-1.5 h-8 mb-6">
                <div className={cn("w-1 bg-accent-systematic rounded-full transition-all duration-300", isSpeaking ? "animate-wave-1 h-6" : "h-2")} />
                <div className={cn("w-1 bg-accent-systematic rounded-full transition-all duration-300", isSpeaking ? "animate-wave-2 h-8" : "h-3")} />
                <div className={cn("w-1 bg-accent-systematic/80 rounded-full transition-all duration-300", isSpeaking ? "animate-wave-3 h-5" : "h-2.5")} />
                <div className={cn("w-1 bg-accent-systematic rounded-full transition-all duration-300", isSpeaking ? "animate-wave-4 h-7" : "h-3")} />
                <div className={cn("w-1 bg-accent-systematic/60 rounded-full transition-all duration-300", isSpeaking ? "animate-wave-5 h-4" : "h-1.5")} />
              </div>
            )}

            <div className="text-center mb-8 h-16">
              <h3 className="text-2xl font-black uppercase tracking-tight text-ink mb-1">
                {isConnecting ? "Conectando..." : isSpeaking ? "Tu Tutor está hablando" : "Tutor escuchando..."}
              </h3>
              <p className="text-ink-muted text-xs px-4 font-sans">
                {isConnecting 
                  ? "Sincronizando el cuaderno con el motor de voz..." 
                  : isSpeaking 
                    ? "Presta atención a la explicación, pregunta o pista" 
                    : "Respóndele directamente por voz para desbloquear la siguiente ficha"}
              </p>
            </div>

            <div className="w-full bg-bg-systematic rounded-full h-2 mb-4 overflow-hidden border border-white/5">
              <div 
                className="bg-accent-systematic h-full transition-all duration-1000 rounded-full"
                style={{ width: `${topics.length > 0 ? (unlockedTopics.length / topics.length) * 100 : 0}%` }}
              />
            </div>
            <p className="text-[10px] text-ink-muted font-mono font-bold mb-8 uppercase tracking-widest bg-bg-systematic px-3 py-1.5 border border-white/5">
              Progreso: <span className="text-accent-systematic font-bold">{unlockedTopics.length}</span> de <span className="text-white font-bold">{topics.length}</span> fichas completadas
            </p>

            <button
              onClick={onEnd}
              className="bg-bg-systematic border border-white/5 hover:border-accent-systematic hover:bg-accent-systematic hover:text-black text-ink font-mono text-[10px] uppercase tracking-widest py-3 px-8 transition-all duration-200 active:scale-[0.98] cursor-pointer"
            >
              Pausar Sesión de Voz
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function FreeStudySession({ 
  text, 
  onEnd 
}: { 
  text: string; 
  onEnd: () => void; 
}) {
  const [isConnecting, setIsConnecting] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const sessionRef = useRef<any>(null);
  const playerRef = useRef<AudioStreamPlayer | null>(null);
  const recorderRef = useRef<AudioRecorder | null>(null);

  useEffect(() => {
    let isMounted = true;

    const startSession = async () => {
      try {
        try {
          const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          micStream.getTracks().forEach(track => track.stop());
        } catch (micErr) {
          console.error("Microphone access failed:", micErr);
          if (isMounted) {
            setError("No se pudo acceder al micrófono. Por favor permite el acceso al micrófono en tu navegador e intenta de nuevo.");
            setIsConnecting(false);
          }
          return;
        }

        playerRef.current = new AudioStreamPlayer(24000);
        
        const session = new WebSocketSession({
          mode: 'free',
          text,
        });

        const sessionPromise = Promise.resolve(session);

        session.setCallbacks({
          onopen: () => {
            if (!isMounted) return;
            setIsConnecting(false);
            
            recorderRef.current = new AudioRecorder((base64) => {
              sessionPromise.then(session => {
                session.sendRealtimeInput({
                  audio: { data: base64, mimeType: 'audio/pcm;rate=16000' }
                });
              });
            });
            recorderRef.current.start().catch((err: any) => {
              console.error("Error starting recording:", err);
              if (isMounted) {
                setError("No se pudo iniciar el grabador de audio. Por favor verifica los permisos.");
                setIsConnecting(false);
              }
            });
          },
          onmessage: (message: any) => {
            if (!isMounted) return;
            
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              setIsSpeaking(true);
              playerRef.current?.addPCM16(base64Audio);
            }
            
            if (message.serverContent?.interrupted) {
              playerRef.current?.interrupt();
              setIsSpeaking(false);
            }
            
            if (message.serverContent?.turnComplete) {
              setIsSpeaking(false);
            }
          },
          onclose: () => {
            if (isMounted) {
              onEnd();
            }
          },
          onerror: (err: any) => {
            console.error("Live API Error:", err);
            if (isMounted) {
              setError(err?.message || "Se perdió la conexión con el tutor.");
            }
          }
        });
        
        sessionRef.current = sessionPromise;
      } catch (err) {
        console.error("Failed to start session:", err);
        if (isMounted) {
          setError("No se pudo iniciar la sesión. Verifica tus permisos de micrófono.");
          setIsConnecting(false);
        }
      }
    };

    startSession();

    return () => {
      isMounted = false;
      recorderRef.current?.stop();
      playerRef.current?.stop();
      sessionRef.current?.then((s: any) => s.close());
    };
  }, [text, onEnd]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] max-w-2xl mx-auto p-6 animate-in fade-in duration-300">
      <div className="w-full flex flex-col items-center justify-center bg-panel-systematic border border-white/5 p-12 shadow-[6px_6px_0px_#161616]">
        {error ? (
          <div className="bg-red-950/20 border border-red-900/30 text-red-400 p-6 rounded-2xl w-full text-center">
            <p className="font-semibold mb-4 text-sm">{error}</p>
            {(error.includes("GEMINI_API_KEY") || error.includes("clave API")) && (
              <div className="mt-4 text-white">
                <ApiKeyErrorGuide />
              </div>
            )}
            {(error.toLowerCase().includes("micrófono") || error.toLowerCase().includes("permis") || error.toLowerCase().includes("denied")) && (
              <div className="mt-4 text-white">
                <MicErrorGuide />
              </div>
            )}
            <button
              onClick={onEnd}
              className="mt-6 bg-red-950/40 hover:bg-red-900/40 text-red-200 border border-red-900/30 px-5 py-2.5 rounded-xl font-bold text-xs transition-colors cursor-pointer"
            >
              Volver al cuaderno
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center w-full">
            <div className="relative w-48 h-48 mb-6 flex items-center justify-center">
              {/* Pulsing background rings */}
              <div className={cn(
                "absolute inset-0 rounded-full bg-accent-systematic/10 transition-all duration-500",
                isConnecting ? "animate-ping" : isSpeaking ? "animate-pulse scale-150 opacity-20" : "scale-110"
              )} />
              <div className={cn(
                "absolute inset-4 rounded-full bg-accent-systematic/15 transition-all duration-300",
                isSpeaking ? "animate-pulse scale-125 opacity-35" : "scale-100"
              )} />
              
              {/* Center orb */}
              <div className={cn(
                "relative z-10 w-24 h-24 rounded-full flex items-center justify-center shadow-lg transition-all duration-500 border border-white/10",
                isConnecting ? "bg-bg-systematic text-ink-muted" : "bg-accent-systematic text-black shadow-[4px_4px_0px_#000000]"
              )}>
                {isConnecting ? (
                  <Loader2 className="w-8 h-8 animate-spin" />
                ) : isSpeaking ? (
                  <Volume2 className="w-8 h-8 text-black animate-bounce" />
                ) : (
                  <Mic className="w-8 h-8 text-black" />
                )}
              </div>
            </div>

            {/* Siri/Gemini wave indicator */}
            {!isConnecting && (
              <div className="flex items-end justify-center gap-1.5 h-8 mb-6">
                <div className={cn("w-1 bg-accent-systematic rounded-full transition-all duration-300", isSpeaking ? "animate-wave-1 h-6" : "h-2")} />
                <div className={cn("w-1 bg-accent-systematic rounded-full transition-all duration-300", isSpeaking ? "animate-wave-2 h-8" : "h-3")} />
                <div className={cn("w-1 bg-accent-systematic/80 rounded-full transition-all duration-300", isSpeaking ? "animate-wave-3 h-5" : "h-2.5")} />
                <div className={cn("w-1 bg-accent-systematic rounded-full transition-all duration-300", isSpeaking ? "animate-wave-4 h-7" : "h-3")} />
                <div className={cn("w-1 bg-accent-systematic/60 rounded-full transition-all duration-300", isSpeaking ? "animate-wave-5 h-4" : "h-1.5")} />
              </div>
            )}

            <div className="text-center mb-8">
              <span className="font-mono text-[9px] text-accent-systematic uppercase tracking-widest block mb-1">
                Asistente de Voz / Modo Libre
              </span>
              <h3 className="text-2xl font-black uppercase tracking-tight text-ink mb-2">
                {isConnecting ? "Iniciando tutoría libre..." : isSpeaking ? "Tutor explicando..." : "Tutor escuchando..."}
              </h3>
              <p className="text-ink-muted text-xs px-6 leading-relaxed max-w-sm mx-auto font-sans">
                {isConnecting 
                  ? "Conectando al canal de voz de Gemini..." 
                  : isSpeaking 
                    ? "Escucha atentamente el análisis de tu cuaderno" 
                    : "Haz cualquier pregunta en voz alta sobre el texto y te responderé de inmediato"}
              </p>
            </div>

            <button
              onClick={onEnd}
              className="bg-bg-systematic border border-white/5 hover:border-accent-systematic hover:bg-accent-systematic hover:text-black text-ink font-mono text-[10px] uppercase tracking-widest py-3 px-8 transition-all duration-200 active:scale-[0.98] cursor-pointer"
            >
              Terminar Sesión Libre
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function MultipleChoiceQuiz({ 
  text, 
  onEnd,
  savedQuestions = [],
  onSaveQuestions,
  onRegenerate
}: { 
  text: string; 
  onEnd: () => void;
  savedQuestions?: QuizQuestion[];
  onSaveQuestions?: (questions: QuizQuestion[]) => void;
  onRegenerate?: () => void;
  key?: string;
}) {
  const [questions, setQuestions] = useState<QuizQuestion[]>(savedQuestions);
  const [loading, setLoading] = useState(savedQuestions.length === 0);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [showConfirmRegen, setShowConfirmRegen] = useState(false);

  const onSaveQuestionsRef = useRef(onSaveQuestions);
  const onEndRef = useRef(onEnd);

  useEffect(() => {
    onSaveQuestionsRef.current = onSaveQuestions;
  }, [onSaveQuestions]);

  useEffect(() => {
    onEndRef.current = onEnd;
  }, [onEnd]);

  useEffect(() => {
    if (questions.length > 0) {
      setLoading(false);
      return;
    }

    let isMounted = true;
    const fetchQuestions = async () => {
      setLoading(true);
      try {
        const res = await fetch("/api/generate-quiz", {
          method: "POST",
          headers: getFetchHeaders(),
          body: JSON.stringify({ text }),
        });
        if (!res.ok) {
          let errorMsg = `Server returned status ${res.status}`;
          try {
            const errData = await res.json();
            if (errData && errData.error) {
              errorMsg = errData.error;
            }
          } catch (_) {}
          throw new Error(errorMsg);
        }
        const data = await res.json();

        if (!isMounted) return;

        const responseText = data.text || '[]';
        const cleanText = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
        const parsed = JSON.parse(cleanText);
        
        if (parsed.length === 0) {
          throw new Error('No se generaron preguntas');
        }
        
        setQuestions(parsed);
        if (onSaveQuestionsRef.current) {
          onSaveQuestionsRef.current(parsed);
        }
      } catch (error: any) {
        console.error('Error generating quiz:', error);
        if (isMounted) {
          alert((error.message || 'Hubo un error al generar el cuestionario exhaustivo.') + ' Por favor, intenta de nuevo.');
          if (onEndRef.current) {
            onEndRef.current();
          }
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchQuestions();

    return () => {
      isMounted = false;
    };
  }, [text, questions.length]);

  const handleRegenerate = () => {
    setShowConfirmRegen(true);
  };

  const confirmRegenerate = () => {
    setShowConfirmRegen(false);
    if (onRegenerate) {
      onRegenerate();
    } else {
      setQuestions([]);
      setCurrentIndex(0);
      setSelected(null);
      setIsAnswered(false);
      setScore(0);
      setIsFinished(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center max-w-md mx-auto p-8 animate-in fade-in duration-300">
        <div className="relative w-24 h-24 mb-6 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border border-white/5 animate-ping" />
          <Loader2 className="w-8 h-8 text-accent-systematic animate-spin" />
        </div>
        <h3 className="text-xl font-black uppercase tracking-tight text-ink">Generando cuestionario...</h3>
        <p className="text-ink-muted text-xs mt-3 leading-relaxed font-mono uppercase">
          Nuestra IA está analizando los conceptos principales y secundarios de tu cuaderno para formular preguntas clave. Esto tomará solo unos segundos.
        </p>
      </div>
    );
  }

  if (questions.length === 0) {
    return null;
  }

  if (isFinished) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] max-w-xl mx-auto text-center animate-in fade-in zoom-in-95 duration-500 p-6">
        <div className="bg-panel-systematic p-12 border border-white/5 w-full relative overflow-hidden shadow-[8px_8px_0px_#161616]">
          <div className="absolute top-0 left-0 w-full h-1 bg-accent-systematic" />
          
          <div className="w-16 h-16 bg-bg-systematic text-accent-systematic border border-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
            <Sparkles className="w-8 h-8 animate-pulse" />
          </div>
          <h2 className="text-3xl font-black uppercase tracking-tight text-ink mb-3">¡Cuestionario Terminado!</h2>
          <p className="text-xs text-ink-muted mb-8 max-w-sm mx-auto leading-relaxed">
            Has completado con éxito la comprobación de lectura inteligente de tus fuentes.
          </p>
          
          <div className="bg-bg-systematic border border-white/5 p-6 mb-8 max-w-sm mx-auto flex items-center justify-around">
            <div className="flex flex-col">
              <span className="text-[9px] font-mono font-bold text-ink-muted uppercase tracking-widest mb-1">Aciertos</span>
              <span className="text-2xl font-extrabold text-ink font-mono">{score} / {questions.length}</span>
            </div>
            <div className="h-8 w-[1px] bg-white/5" />
            <div className="flex flex-col">
              <span className="text-[9px] font-mono font-bold text-ink-muted uppercase tracking-widest mb-1">Porcentaje</span>
              <span className="text-2xl font-extrabold text-accent-systematic font-mono">
                {Math.round((score / questions.length) * 100)}%
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 w-full max-w-sm mx-auto">
            <button
              onClick={onEnd}
              className="bg-accent-systematic hover:bg-white text-black font-mono text-xs uppercase tracking-widest py-3.5 px-8 border-none transition-all duration-200 active:scale-[0.98] cursor-pointer font-bold w-full"
            >
              Volver al Cuaderno
            </button>
            <button
              onClick={() => {
                if (onRegenerate) {
                  onRegenerate();
                } else {
                  setQuestions([]);
                  setCurrentIndex(0);
                  setSelected(null);
                  setIsAnswered(false);
                  setScore(0);
                  setIsFinished(false);
                }
              }}
              className="border border-white/10 hover:bg-white hover:text-black text-ink font-mono text-xs uppercase tracking-widest py-3.5 px-8 transition-all duration-200 active:scale-[0.98] cursor-pointer font-bold w-full bg-transparent"
            >
              Cuestionario Nuevo
            </button>
          </div>
        </div>
      </div>
    );
  }

  const question = questions[currentIndex];
  const options = question?.options || [];

  const handleSelect = (index: number) => {
    if (isAnswered) return;
    setSelected(index);
    setIsAnswered(true);
    if (index === question.correctIndex) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(i => i + 1);
      setSelected(null);
      setIsAnswered(false);
    } else {
      setIsFinished(true);
    }
  };

  return (
    <div className="max-w-2xl mx-auto animate-in fade-in duration-300 p-6">
      <div className="mb-6 flex items-center justify-between border-b border-white/5 pb-4">
        <div className="flex flex-col">
          <span className="text-[10px] font-mono text-accent-systematic uppercase tracking-widest">Cuestionario Escrito</span>
          <h2 className="text-xl font-black uppercase tracking-tight text-ink font-sans">Pregunta {currentIndex + 1} de {questions.length}</h2>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={handleRegenerate}
            className="font-mono text-[9px] text-accent-systematic hover:text-white bg-transparent border border-white/10 hover:border-white/25 px-2 py-1 rounded transition-colors uppercase tracking-widest cursor-pointer"
          >
            🔄 Regenerar
          </button>
          <span className="font-mono text-xs text-accent-systematic font-bold uppercase tracking-widest">
            Puntos: {score}
          </span>
        </div>
      </div>

      <div className="bg-panel-systematic border border-white/5 p-8 shadow-[6px_6px_0px_#161616] mb-6">
        <h3 className="text-lg font-bold text-ink mb-6 leading-snug uppercase">
          {question?.question}
        </h3>

        <div className="space-y-3">
          {options.map((opt, idx) => {
            const isSelected = selected === idx;
            const isCorrect = idx === question.correctIndex;
            
            let btnClass = "w-full text-left p-4 border transition-all duration-200 flex items-center justify-between text-xs font-medium cursor-pointer ";
            
            if (!isAnswered) {
              btnClass += "border-white/5 bg-bg-systematic hover:border-accent-systematic hover:bg-panel-systematic text-ink hover:translate-x-1";
            } else {
              if (isCorrect) {
                btnClass += "border-emerald-600 bg-emerald-950/20 text-emerald-400 font-bold shadow-[2px_2px_0px_#10b981]";
              } else if (isSelected && !isCorrect) {
                btnClass += "border-accent-systematic bg-rose-950/20 text-rose-400 font-bold shadow-[2px_2px_0px_#ff4d00]";
              } else {
                btnClass += "border-white/5 bg-panel-systematic/25 text-ink-muted opacity-30";
              }
            }

            return (
              <button
                key={idx}
                disabled={isAnswered}
                onClick={() => handleSelect(idx)}
                className={btnClass}
              >
                <span>{opt}</span>
                {isAnswered && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 ml-3" />}
                {isAnswered && isSelected && !isCorrect && <XCircle className="w-4 h-4 text-accent-systematic shrink-0 ml-3" />}
              </button>
            );
          })}
        </div>
      </div>

      {isAnswered && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-panel-systematic border border-white/5 p-5 shadow-[4px_4px_0px_#161616] mb-6"
        >
          <h4 className="font-mono font-bold text-accent-systematic mb-1 flex items-center gap-1.5 text-[10px] uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5 text-accent-systematic" />
            Explicación del Tutor
          </h4>
          <p className="text-ink-muted text-xs leading-relaxed font-sans">
            {question?.explanation}
          </p>
        </motion.div>
      )}

      <div className="flex justify-between items-center mt-8">
        <button
          onClick={onEnd}
          className="font-mono text-[10px] text-ink uppercase tracking-widest border border-white/10 px-4 py-2.5 hover:bg-white hover:text-black transition-colors duration-200 cursor-pointer"
        >
          Salir del Cuestionario
        </button>
        
        <button
          disabled={!isAnswered}
          onClick={handleNext}
          className="bg-accent-systematic hover:bg-white disabled:opacity-30 disabled:cursor-not-allowed text-black font-mono text-[10px] uppercase tracking-widest py-3 px-6 border border-none transition-all duration-200 active:scale-[0.98] cursor-pointer font-bold flex items-center gap-1.5"
        >
          {currentIndex < questions.length - 1 ? "Siguiente Pregunta" : "Ver Resultados"}
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <AnimatePresence>
        {showConfirmRegen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#121212] border border-white/10 p-6 md:p-8 max-w-sm w-full relative shadow-[8px_8px_0px_#161616] text-center"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-accent-systematic" />
              <div className="w-12 h-12 bg-panel-systematic text-accent-systematic border border-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                <HelpCircle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black uppercase tracking-tight text-ink mb-2">
                ¿Generar nuevo?
              </h3>
              <p className="text-xs text-ink-muted leading-relaxed font-sans mb-6">
                Las preguntas actuales se reemplazarán por unas nuevas basadas en tus fuentes de estudio. Perderás tu progreso actual en este cuestionario.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => setShowConfirmRegen(false)}
                  className="flex-1 font-mono text-[10px] text-ink uppercase tracking-widest border border-white/10 px-4 py-3 hover:bg-white/5 transition-colors duration-200 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  onClick={confirmRegenerate}
                  className="flex-1 bg-accent-systematic hover:bg-white text-black font-mono text-[10px] uppercase tracking-widest py-3 px-4 transition-all duration-200 cursor-pointer font-bold"
                >
                  Sí, generar
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

